import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AuthPageClient from "@/components/AuthPageClient";

export const metadata = {
  title: "Sign In | AUREUM Fine Dining",
  description: "Sign in to your AUREUM account to manage reservations, orders, and loyalty rewards.",
};

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-charcoal-dark">
      <Navbar />
      <AuthPageClient />
      <Footer />
    </main>
  );
}
