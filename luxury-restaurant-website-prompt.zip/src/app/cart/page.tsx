import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CartPageClient from "@/components/CartPageClient";

export const metadata = {
  title: "Cart | AUREUM Fine Dining",
  description: "Review your order and checkout.",
};

export default function CartPage() {
  return (
    <main className="min-h-screen bg-charcoal-dark">
      <Navbar />
      <CartPageClient />
      <Footer />
    </main>
  );
}
