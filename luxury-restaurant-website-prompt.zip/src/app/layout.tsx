import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { ThemeProvider } from "@/lib/theme-context";
import { AuthProvider } from "@/lib/auth-context";

export const metadata: Metadata = {
  title: "AUREUM | Premium Fine Dining Restaurant",
  description: "Experience world-class fine dining at AUREUM. Luxury cuisine, exquisite ambiance, and unforgettable moments in the heart of the city. Reserve your table today.",
  keywords: "fine dining, luxury restaurant, premium cuisine, steak house, seafood, reservation, NYC restaurant",
  openGraph: {
    title: "AUREUM | Premium Fine Dining Restaurant",
    description: "Experience world-class fine dining at AUREUM. Luxury cuisine, exquisite ambiance, and unforgettable moments.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" data-theme="dark">
      <body className="antialiased">
        <ThemeProvider>
          <AuthProvider>
            {children}
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
