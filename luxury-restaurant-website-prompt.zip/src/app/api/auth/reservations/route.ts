import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reservations } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get("userId");
    if (!userId) {
      return NextResponse.json({ error: "userId required" }, { status: 400 });
    }
    const userRes = await db.select().from(reservations).where(eq(reservations.userId, parseInt(userId))).orderBy(desc(reservations.createdAt)).limit(50);
    return NextResponse.json(userRes);
  } catch {
    return NextResponse.json([]);
  }
}
