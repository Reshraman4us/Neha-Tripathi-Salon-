import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get("userId");
    if (!userId) {
      return NextResponse.json({ error: "userId required" }, { status: 400 });
    }
    const userOrders = await db.select().from(orders).where(eq(orders.userId, parseInt(userId))).orderBy(desc(orders.createdAt)).limit(50);
    return NextResponse.json(userOrders);
  } catch {
    return NextResponse.json([]);
  }
}
