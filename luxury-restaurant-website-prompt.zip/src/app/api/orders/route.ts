import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { customerName, customerEmail, customerPhone, address, orderType, items, subtotal, tax, tip, total, promoCode, discount, notes, paymentMethod } = body;
    if (!customerName || !customerEmail || !customerPhone || !items || !total) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }
    const [order] = await db.insert(orders).values({
      customerName, customerEmail, customerPhone,
      address: address || null,
      orderType: orderType || "delivery",
      items,
      subtotal: parseFloat(subtotal),
      tax: parseFloat(tax),
      tip: parseFloat(tip || "0"),
      total: parseFloat(total),
      promoCode: promoCode || null,
      discount: parseFloat(discount || "0"),
      notes: notes || null,
      paymentMethod: paymentMethod || "card",
    }).returning();
    return NextResponse.json(order, { status: 201 });
  } catch (error) {
    console.error("Order error:", error);
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 });
  }
}
