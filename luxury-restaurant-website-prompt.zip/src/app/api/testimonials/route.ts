import { NextResponse } from "next/server";
import { db } from "@/db";
import { testimonials } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const res = await db.select().from(testimonials).orderBy(desc(testimonials.createdAt));
    return NextResponse.json(res);
  } catch (error) {
    return NextResponse.json([]);
  }
}
