import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reservations } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const res = await db.select().from(reservations).orderBy(desc(reservations.createdAt)).limit(100);
    return NextResponse.json(res);
  } catch (error) {
    return NextResponse.json([]);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, phone, date, time, guests, occasion, notes } = body;
    if (!name || !email || !phone || !date || !time || !guests) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }
    const [res] = await db.insert(reservations).values({
      name, email, phone, date, time,
      guests: parseInt(guests),
      occasion: occasion || null,
      notes: notes || null,
    }).returning();
    return NextResponse.json(res, { status: 201 });
  } catch (error) {
    console.error("Reservation error:", error);
    return NextResponse.json({ error: "Failed to create reservation" }, { status: 500 });
  }
}
