import { NextResponse } from "next/server";
import { db } from "@/db";
import { menuCategories, menuItems } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

export async function GET() {
  try {
    const categories = await db.select().from(menuCategories).where(eq(menuCategories.active, true)).orderBy(asc(menuCategories.sortOrder));
    const items = await db.select().from(menuItems).where(eq(menuItems.active, true));
    return NextResponse.json({ categories, items });
  } catch (error) {
    console.error("Menu fetch error:", error);
    return NextResponse.json({ categories: [], items: [] });
  }
}
