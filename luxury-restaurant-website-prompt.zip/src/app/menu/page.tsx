import { Suspense } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MenuPageClient from "@/components/MenuPageClient";
import { db } from "@/db";
import { menuCategories, menuItems } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { seedDatabase } from "@/lib/seed";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Menu | AUREUM Fine Dining",
  description: "Explore our exquisite menu crafted by award-winning chefs. From premium steaks to fresh seafood, every dish is a masterpiece.",
};

async function getData() {
  try {
    await seedDatabase();
    const cats = await db.select().from(menuCategories).where(eq(menuCategories.active, true)).orderBy(asc(menuCategories.sortOrder));
    const items = await db.select().from(menuItems).where(eq(menuItems.active, true));
    return { categories: cats, items };
  } catch {
    return { categories: [], items: [] };
  }
}

function MenuFallback() {
  return (
    <div className="pt-28 pb-16 min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-gold/30 border-t-gold rounded-full animate-spin" />
    </div>
  );
}

export default async function MenuPage() {
  const data = await getData();
  return (
    <main className="min-h-screen bg-charcoal-dark">
      <Navbar />
      <Suspense fallback={<MenuFallback />}>
        <MenuPageClient categories={data.categories} items={data.items} />
      </Suspense>
      <Footer />
    </main>
  );
}
