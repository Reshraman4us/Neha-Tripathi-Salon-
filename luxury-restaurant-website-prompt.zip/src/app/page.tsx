import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import HeroSection from "@/components/sections/HeroSection";
import AboutSection from "@/components/sections/AboutSection";
import MenuPreview from "@/components/sections/MenuPreview";
import ReservationSection from "@/components/sections/ReservationSection";
import GallerySection from "@/components/sections/GallerySection";
import TestimonialsSection from "@/components/sections/TestimonialsSection";
import StatsSection from "@/components/sections/StatsSection";
import ContactSection from "@/components/sections/ContactSection";
import CTASection from "@/components/sections/CTASection";
import { db } from "@/db";
import { menuCategories, menuItems, testimonials } from "@/db/schema";
import { eq, asc, desc } from "drizzle-orm";
import { seedDatabase } from "@/lib/seed";

export const dynamic = "force-dynamic";

async function getData() {
  try {
    await seedDatabase();
    const cats = await db.select().from(menuCategories).where(eq(menuCategories.active, true)).orderBy(asc(menuCategories.sortOrder));
    const items = await db.select().from(menuItems).where(eq(menuItems.active, true));
    const reviews = await db.select().from(testimonials).orderBy(desc(testimonials.createdAt));
    return { categories: cats, menuItems: items, testimonials: reviews };
  } catch {
    return { categories: [], menuItems: [], testimonials: [] };
  }
}

export default async function Home() {
  const data = await getData();

  return (
    <main className="min-h-screen bg-charcoal-dark">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <StatsSection />
      <MenuPreview categories={data.categories} items={data.menuItems} />
      <ReservationSection />
      <GallerySection />
      <TestimonialsSection testimonials={data.testimonials} />
      <CTASection />
      <ContactSection />
      <Footer />
    </main>
  );
}
