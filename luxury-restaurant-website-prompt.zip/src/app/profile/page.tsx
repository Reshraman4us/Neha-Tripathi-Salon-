import { Suspense } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProfilePageClient from "@/components/ProfilePageClient";

export const metadata = {
  title: "My Profile | AUREUM Fine Dining",
  description: "Manage your AUREUM account, view orders, reservations, favorites, and loyalty rewards.",
};

function ProfileFallback() {
  return (
    <div className="pt-28 pb-16 min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-gold/30 border-t-gold rounded-full animate-spin" />
    </div>
  );
}

export default function ProfilePage() {
  return (
    <main className="min-h-screen bg-charcoal-dark">
      <Navbar />
      <Suspense fallback={<ProfileFallback />}>
        <ProfilePageClient />
      </Suspense>
      <Footer />
    </main>
  );
}
