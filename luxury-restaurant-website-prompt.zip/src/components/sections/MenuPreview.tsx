"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { Star, Flame, Leaf, ShoppingBag, ArrowRight } from "lucide-react";
import { addToCart } from "@/lib/cart-store";

interface Category {
  id: number;
  name: string;
  slug: string;
}

interface MenuItem {
  id: number;
  categoryId: number;
  name: string;
  slug: string;
  description: string | null;
  price: number;
  image: string | null;
  calories: number | null;
  ingredients: string | null;
  isVegan: boolean | null;
  isSpicy: boolean | null;
  isPopular: boolean | null;
  isNew: boolean | null;
  rating: number | null;
  reviewCount: number | null;
}

interface Props {
  categories: Category[];
  items: MenuItem[];
}

export default function MenuPreview({ categories, items }: Props) {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const displayCategories = categories.slice(0, 6);
  const filteredItems = activeCategory
    ? items.filter((item) => {
        const cat = categories.find((c) => c.slug === activeCategory);
        return cat && item.categoryId === cat.id;
      })
    : items.filter((item) => item.isPopular);

  const displayItems = filteredItems.slice(0, 8);

  const handleAddToCart = (item: MenuItem) => {
    addToCart({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image || "",
    });
  };

  return (
    <section id="menu" className="py-24 lg:py-32 relative">
      <div className="absolute inset-0 bg-gradient-dark" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-gold text-sm font-inter tracking-[0.2em] uppercase mb-4 block">Our Menu</span>
          <h2 className="font-playfair text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            <span className="text-cream">Crafted with </span>
            <span className="text-gradient">Passion</span>
          </h2>
          <p className="text-cream/50 font-inter max-w-2xl mx-auto">
            Discover our exquisite collection of dishes, each crafted with the finest ingredients and presented as edible art.
          </p>
        </motion.div>

        {/* Category Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          <button
            onClick={() => setActiveCategory(null)}
            className={`px-6 py-2.5 rounded-full text-sm font-inter tracking-wider uppercase transition-all ${
              !activeCategory ? "bg-gradient-gold text-charcoal-dark font-semibold" : "glass-light text-cream/60 hover:text-gold"
            }`}
          >
            Popular
          </button>
          {displayCategories.map((cat) => (
            <button
              key={cat.slug}
              onClick={() => setActiveCategory(cat.slug)}
              className={`px-6 py-2.5 rounded-full text-sm font-inter tracking-wider uppercase transition-all ${
                activeCategory === cat.slug ? "bg-gradient-gold text-charcoal-dark font-semibold" : "glass-light text-cream/60 hover:text-gold"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </motion.div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <AnimatePresence mode="popLayout">
            {displayItems.map((item, i) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
                className="group menu-card-hover glass rounded-2xl overflow-hidden"
              >
                <div className="relative h-52 overflow-hidden">
                  <img
                    src={item.image || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500"}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal-dark/80 to-transparent" />
                  
                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex gap-2">
                    {item.isNew && (
                      <span className="px-2 py-1 rounded-full bg-warm-orange/90 text-white text-xs font-semibold">NEW</span>
                    )}
                    {item.isSpicy && (
                      <span className="px-2 py-1 rounded-full bg-wine/90 text-white text-xs font-semibold flex items-center gap-1">
                        <Flame size={10} /> Spicy
                      </span>
                    )}
                    {item.isVegan && (
                      <span className="px-2 py-1 rounded-full bg-green-600/90 text-white text-xs font-semibold flex items-center gap-1">
                        <Leaf size={10} /> Vegan
                      </span>
                    )}
                  </div>

                  {/* Add to cart button */}
                  <button
                    onClick={() => handleAddToCart(item)}
                    className="absolute top-3 right-3 w-9 h-9 rounded-full bg-gold/90 text-charcoal-dark flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-gold hover:scale-110"
                  >
                    <ShoppingBag size={16} />
                  </button>

                  {/* Price */}
                  <div className="absolute bottom-3 right-3 bg-gold/90 text-charcoal-dark px-3 py-1 rounded-full text-sm font-bold">
                    ${item.price}
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="font-playfair text-lg font-semibold text-cream mb-1 group-hover:text-gold transition-colors">
                    {item.name}
                  </h3>
                  <p className="text-cream/40 text-sm font-inter line-clamp-2 mb-3">
                    {item.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Star size={14} className="text-gold fill-gold" />
                      <span className="text-gold text-sm font-semibold">{item.rating}</span>
                      <span className="text-cream/30 text-xs">({item.reviewCount})</span>
                    </div>
                    {item.calories && (
                      <span className="text-cream/30 text-xs font-inter">{item.calories} cal</span>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* View Full Menu */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Link
            href="/menu"
            className="inline-flex items-center gap-2 btn-premium bg-gradient-gold text-charcoal-dark px-8 py-4 rounded-full font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all"
          >
            View Full Menu
            <ArrowRight size={18} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
