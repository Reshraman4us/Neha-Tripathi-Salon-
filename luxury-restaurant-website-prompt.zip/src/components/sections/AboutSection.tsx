"use client";

import { motion } from "framer-motion";
import { Award, Flame, Star, Users } from "lucide-react";

const highlights = [
  { icon: Award, label: "Michelin Stars", value: "2 Stars" },
  { icon: Flame, label: "Years of Excellence", value: "8+" },
  { icon: Star, label: "Guest Rating", value: "4.9/5" },
  { icon: Users, label: "Happy Guests", value: "50K+" },
];

export default function AboutSection() {
  return (
    <section id="about" className="py-24 lg:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Images */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1600891964092-4316c288032e?w=600&q=80"
                alt="Signature steak"
                className="w-full h-[500px] object-cover rounded-2xl"
              />
              <div className="absolute -bottom-6 -right-6 w-48 h-48 rounded-2xl overflow-hidden border-4 border-charcoal-dark shadow-2xl hidden md:block">
                <img
                  src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=300&q=80"
                  alt="Chef preparing dish"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -top-4 -left-4 glass px-6 py-4 rounded-xl hidden md:block">
                <p className="text-gold font-playfair text-2xl font-bold">8+</p>
                <p className="text-cream/60 text-xs font-inter uppercase tracking-wider">Years of Excellence</p>
              </div>
            </div>
          </motion.div>

          {/* Right - Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-gold text-sm font-inter tracking-[0.2em] uppercase mb-4 block">Our Story</span>
            <h2 className="font-playfair text-4xl md:text-5xl font-bold mb-6 leading-tight">
              <span className="text-cream">A Legacy of</span>
              <br />
              <span className="text-gradient">Culinary Excellence</span>
            </h2>
            <p className="text-cream/60 font-inter leading-relaxed mb-6">
              Founded in 2018 by Chef Alessandro Romano, AUREUM was born from a passion 
              for transforming the finest ingredients into extraordinary culinary experiences. 
              Every dish is a celebration of flavor, artistry, and the timeless traditions 
              of world cuisine.
            </p>
            <p className="text-cream/60 font-inter leading-relaxed mb-8">
              Our award-winning team sources premium ingredients from local farms and 
              international purveyors, crafting menus that honor seasonal bounty while 
              pushing creative boundaries. From our hand-selected A5 Wagyu to our 
              freshly caught Atlantic seafood, every element is curated for perfection.
            </p>

            <div className="grid grid-cols-2 gap-4 mb-8">
              {highlights.map((h) => (
                <div key={h.label} className="glass-light rounded-xl p-4 text-center">
                  <h.icon className="mx-auto text-gold mb-2" size={24} />
                  <p className="text-gold font-playfair text-xl font-bold">{h.value}</p>
                  <p className="text-cream/50 text-xs font-inter uppercase tracking-wider">{h.label}</p>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <img
                src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=100&q=80"
                alt="Chef Alessandro"
                className="w-14 h-14 rounded-full object-cover border-2 border-gold/30"
              />
              <div>
                <p className="text-cream font-playfair font-semibold">Chef Alessandro Romano</p>
                <p className="text-cream/50 text-sm font-inter">Executive Chef &amp; Founder</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
