"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Calendar, Clock, Users, Sparkles, CheckCircle2 } from "lucide-react";

const timeSlots = [
  "5:00 PM", "5:30 PM", "6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM",
  "8:00 PM", "8:30 PM", "9:00 PM", "9:30 PM", "10:00 PM",
];

const occasions = ["Birthday", "Anniversary", "Business Dinner", "Date Night", "Celebration", "Other"];

export default function ReservationSection() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", date: "", time: "", guests: "2", occasion: "", notes: "" });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Failed to book");
      setSuccess(true);
      setForm({ name: "", email: "", phone: "", date: "", time: "", guests: "2", occasion: "", notes: "" });
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  // Get min date (today)
  const today = new Date().toISOString().split("T")[0];

  return (
    <section id="reservations" className="py-24 lg:py-32 relative overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1559339352-11d035aa65de?w=1920&q=80"
          alt="Dining ambiance"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal-dark/92 backdrop-blur-sm" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-gold text-sm font-inter tracking-[0.2em] uppercase mb-4 block">Reservations</span>
          <h2 className="font-playfair text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            <span className="text-cream">Reserve Your </span>
            <span className="text-gradient">Experience</span>
          </h2>
          <p className="text-cream/50 font-inter max-w-2xl mx-auto">
            Secure your table at AUREUM for an unforgettable evening. Special occasions deserve extraordinary settings.
          </p>
        </motion.div>

        {success ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-3xl p-12 text-center max-w-lg mx-auto"
          >
            <CheckCircle2 className="mx-auto text-gold mb-6" size={64} />
            <h3 className="font-playfair text-3xl font-bold text-cream mb-4">Reservation Confirmed!</h3>
            <p className="text-cream/60 font-inter mb-6">
              Thank you for choosing AUREUM. We&apos;ve sent a confirmation to your email. 
              We look forward to welcoming you.
            </p>
            <button
              onClick={() => setSuccess(false)}
              className="btn-premium bg-gradient-gold text-charcoal-dark px-8 py-3 rounded-full font-semibold tracking-wider uppercase"
            >
              Make Another Reservation
            </button>
          </motion.div>
        ) : (
          <motion.form
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            onSubmit={handleSubmit}
            className="glass rounded-3xl p-8 md:p-12"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Name */}
              <div>
                <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase">Full Name *</label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                  placeholder="John Smith"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase">Email *</label>
                <input
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                  placeholder="john@example.com"
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase">Phone *</label>
                <input
                  type="tel"
                  required
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                  placeholder="(212) 555-1234"
                />
              </div>

              {/* Guests */}
              <div>
                <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase flex items-center gap-2">
                  <Users size={14} /> Guests *
                </label>
                <select
                  required
                  value={form.guests}
                  onChange={(e) => setForm({ ...form, guests: e.target.value })}
                  className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter focus:outline-none focus:border-gold/60 transition-colors"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 15, 20].map((n) => (
                    <option key={n} value={n}>{n} {n === 1 ? "Guest" : "Guests"}</option>
                  ))}
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase flex items-center gap-2">
                  <Calendar size={14} /> Date *
                </label>
                <input
                  type="date"
                  required
                  min={today}
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                  className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter focus:outline-none focus:border-gold/60 transition-colors"
                />
              </div>

              {/* Time */}
              <div>
                <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase flex items-center gap-2">
                  <Clock size={14} /> Time *
                </label>
                <select
                  required
                  value={form.time}
                  onChange={(e) => setForm({ ...form, time: e.target.value })}
                  className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter focus:outline-none focus:border-gold/60 transition-colors"
                >
                  <option value="">Select Time</option>
                  {timeSlots.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              {/* Occasion */}
              <div>
                <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase flex items-center gap-2">
                  <Sparkles size={14} /> Occasion
                </label>
                <select
                  value={form.occasion}
                  onChange={(e) => setForm({ ...form, occasion: e.target.value })}
                  className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter focus:outline-none focus:border-gold/60 transition-colors"
                >
                  <option value="">Select Occasion</option>
                  {occasions.map((o) => (
                    <option key={o} value={o}>{o}</option>
                  ))}
                </select>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase">Special Requests</label>
                <input
                  type="text"
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                  placeholder="Dietary restrictions, seating preference..."
                />
              </div>
            </div>

            {error && (
              <p className="text-red-400 text-sm font-inter mt-4">{error}</p>
            )}

            <div className="mt-8 text-center">
              <button
                type="submit"
                disabled={submitting}
                className="btn-premium bg-gradient-gold text-charcoal-dark px-12 py-4 rounded-full font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-lg"
              >
                {submitting ? "Booking..." : "Reserve My Table"}
              </button>
              <p className="text-cream/30 text-xs font-inter mt-4">
                You will receive a confirmation email within minutes.
              </p>
            </div>
          </motion.form>
        )}
      </div>
    </section>
  );
}
