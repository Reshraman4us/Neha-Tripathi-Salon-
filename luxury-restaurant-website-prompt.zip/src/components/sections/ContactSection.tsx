"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2 } from "lucide-react";

export default function ContactSection() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      setSuccess(true);
      setForm({ name: "", email: "", phone: "", subject: "", message: "" });
    } catch {
      // silently fail
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 lg:py-32 relative">
      <div className="absolute inset-0 bg-gradient-dark" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-gold text-sm font-inter tracking-[0.2em] uppercase mb-4 block">Contact Us</span>
          <h2 className="font-playfair text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            <span className="text-cream">Get in </span>
            <span className="text-gradient">Touch</span>
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="space-y-8 mb-10">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center shrink-0">
                  <MapPin className="text-gold" size={22} />
                </div>
                <div>
                  <h4 className="text-cream font-playfair font-semibold mb-1">Visit Us</h4>
                  <p className="text-cream/50 font-inter text-sm">123 Fifth Avenue, Manhattan<br />New York, NY 10010</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center shrink-0">
                  <Phone className="text-gold" size={22} />
                </div>
                <div>
                  <h4 className="text-cream font-playfair font-semibold mb-1">Call Us</h4>
                  <p className="text-cream/50 font-inter text-sm">(212) 555-1234<br />Available during business hours</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center shrink-0">
                  <Mail className="text-gold" size={22} />
                </div>
                <div>
                  <h4 className="text-cream font-playfair font-semibold mb-1">Email Us</h4>
                  <p className="text-cream/50 font-inter text-sm">hello@aureum.com<br />events@aureum.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center shrink-0">
                  <Clock className="text-gold" size={22} />
                </div>
                <div>
                  <h4 className="text-cream font-playfair font-semibold mb-1">Hours</h4>
                  <p className="text-cream/50 font-inter text-sm">
                    Mon–Thu: 5PM – 11PM<br />
                    Fri–Sat: 5PM – 12AM<br />
                    Sunday: 4PM – 10PM
                  </p>
                </div>
              </div>
            </div>

            {/* Map Embed */}
            <div className="rounded-2xl overflow-hidden border border-gold/10 h-[250px]">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.9663095343008!2d-73.98823368459471!3d40.74065987932881!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259a9b3117469%3A0xd134e199a405a163!2sEmpire%20State%20Building!5e0!3m2!1sen!2sus!4v1629800000000!5m2!1sen!2sus"
                width="100%"
                height="100%"
                style={{ border: 0, filter: "invert(90%) hue-rotate(180deg)" }}
                allowFullScreen
                loading="lazy"
                title="Restaurant location"
              />
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            {success ? (
              <div className="glass rounded-3xl p-12 text-center h-full flex flex-col items-center justify-center">
                <CheckCircle2 className="text-gold mb-6" size={48} />
                <h3 className="font-playfair text-2xl font-bold text-cream mb-4">Message Sent!</h3>
                <p className="text-cream/60 font-inter mb-6">We&apos;ll get back to you within 24 hours.</p>
                <button
                  onClick={() => setSuccess(false)}
                  className="btn-premium bg-gradient-gold text-charcoal-dark px-8 py-3 rounded-full font-semibold tracking-wider uppercase"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="glass rounded-3xl p-8 md:p-10">
                <div className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase">Name *</label>
                      <input
                        type="text"
                        required
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase">Email *</label>
                      <input
                        type="email"
                        required
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase">Phone</label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                        placeholder="(555) 123-4567"
                      />
                    </div>
                    <div>
                      <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase">Subject</label>
                      <select
                        value={form.subject}
                        onChange={(e) => setForm({ ...form, subject: e.target.value })}
                        className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter focus:outline-none focus:border-gold/60 transition-colors"
                      >
                        <option value="">Select subject</option>
                        <option value="General Inquiry">General Inquiry</option>
                        <option value="Private Events">Private Events</option>
                        <option value="Catering">Catering</option>
                        <option value="Feedback">Feedback</option>
                        <option value="Careers">Careers</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-cream/70 text-sm font-inter mb-2 tracking-wider uppercase">Message *</label>
                    <textarea
                      required
                      rows={5}
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors resize-none"
                      placeholder="Tell us how we can help..."
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full btn-premium bg-gradient-gold text-charcoal-dark px-8 py-4 rounded-full font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <Send size={18} />
                    {submitting ? "Sending..." : "Send Message"}
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
