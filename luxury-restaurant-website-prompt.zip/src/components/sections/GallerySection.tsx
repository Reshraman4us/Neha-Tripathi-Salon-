"use client";

import { motion } from "framer-motion";

const galleryImages = [
  { src: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80", alt: "Fine dining table", span: "col-span-2 row-span-2" },
  { src: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600&q=80", alt: "Gourmet plating", span: "" },
  { src: "https://images.unsplash.com/photo-1551218808-94e220e084d2?w=600&q=80", alt: "Restaurant bar", span: "" },
  { src: "https://images.unsplash.com/photo-1600891964092-4316c288032e?w=600&q=80", alt: "Wagyu steak", span: "" },
  { src: "https://images.unsplash.com/photo-1559339352-11d035aa65de?w=600&q=80", alt: "Dinner ambiance", span: "" },
  { src: "https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=600&q=80", alt: "Chef at work", span: "col-span-2" },
];

export default function GallerySection() {
  return (
    <section id="gallery" className="py-24 lg:py-32 relative">
      <div className="absolute inset-0 bg-gradient-dark" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-gold text-sm font-inter tracking-[0.2em] uppercase mb-4 block">Gallery</span>
          <h2 className="font-playfair text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            <span className="text-cream">A Feast for </span>
            <span className="text-gradient">the Eyes</span>
          </h2>
          <p className="text-cream/50 font-inter max-w-2xl mx-auto">
            Immerse yourself in the visual splendor of AUREUM — from our meticulously plated dishes to our breathtaking dining spaces.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 auto-rows-[250px]">
          {galleryImages.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className={`relative rounded-2xl overflow-hidden group cursor-pointer ${img.span}`}
            >
              <img
                src={img.src}
                alt={img.alt}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-charcoal-dark/0 group-hover:bg-charcoal-dark/50 transition-all duration-500 flex items-end justify-start p-6">
                <p className="text-cream font-playfair text-lg opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-500">
                  {img.alt}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
