"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ChevronDown, Play } from "lucide-react";

export default function HeroSection() {
  return (
    <section id="home" className="relative h-screen min-h-[700px] flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1920&q=80"
          alt="Fine dining ambiance"
          className="w-full h-full object-cover"
        />
        <div className="hero-overlay absolute inset-0" />
      </div>

      {/* Animated particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-gold/30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="mb-6"
        >
          <span className="inline-flex items-center gap-2 px-5 py-2 rounded-full glass-light text-gold text-sm font-inter tracking-[0.2em] uppercase">
            <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />
            Est. 2018 — New York City
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="font-playfair text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold mb-6 leading-[1.1]"
        >
          <span className="text-cream">Where Every</span>
          <br />
          <span className="text-gradient">Flavor Tells</span>
          <br />
          <span className="text-cream italic">a Story</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.7 }}
          className="text-cream/60 text-lg md:text-xl max-w-2xl mx-auto mb-10 font-inter leading-relaxed"
        >
          Experience world-class fine dining crafted by award-winning chefs. 
          Premium ingredients, exquisite presentation, unforgettable moments.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.9 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Link
            href="/#reservations"
            className="btn-premium bg-gradient-gold text-charcoal-dark px-8 py-4 rounded-full text-sm font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all min-w-[200px]"
          >
            Book a Table
          </Link>
          <Link
            href="/menu"
            className="btn-premium glass-light text-gold px-8 py-4 rounded-full text-sm font-semibold tracking-wider uppercase hover:bg-gold/20 transition-all min-w-[200px]"
          >
            Order Online
          </Link>
          <Link
            href="/menu"
            className="flex items-center gap-2 text-cream/60 hover:text-gold transition-colors text-sm tracking-wider uppercase font-inter"
          >
            <span className="w-10 h-10 rounded-full glass-light flex items-center justify-center">
              <Play size={16} className="ml-0.5" />
            </span>
            Explore Menu
          </Link>
        </motion.div>

        {/* Trust badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.3 }}
          className="mt-16 flex flex-wrap items-center justify-center gap-8"
        >
          {[
            { label: "Michelin", value: "⭐⭐" },
            { label: "Zagat Rated", value: "4.9/5" },
            { label: "James Beard", value: "Winner" },
          ].map((badge) => (
            <div key={badge.label} className="text-center">
              <p className="text-gold font-playfair text-lg font-bold">{badge.value}</p>
              <p className="text-cream/40 text-xs font-inter tracking-wider uppercase">{badge.label}</p>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <ChevronDown className="text-gold/40" size={28} />
      </motion.div>
    </section>
  );
}
