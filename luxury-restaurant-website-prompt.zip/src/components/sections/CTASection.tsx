"use client";

import { motion } from "framer-motion";
import Link from "next/link";

export default function CTASection() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1920&q=80"
          alt="Restaurant evening"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal-dark/85" />
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-gold text-sm font-inter tracking-[0.2em] uppercase mb-4 block">Order Online</span>
          <h2 className="font-playfair text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-cream">Bring AUREUM </span>
            <span className="text-gradient">to Your Door</span>
          </h2>
          <p className="text-cream/50 font-inter max-w-2xl mx-auto mb-10 text-lg">
            Can&apos;t make it to the restaurant? Enjoy our premium cuisine from the comfort of your home. 
            Order online for delivery or pickup.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/menu"
              className="btn-premium bg-gradient-gold text-charcoal-dark px-10 py-4 rounded-full font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all text-lg"
            >
              Order Now
            </Link>
            <Link
              href="/#reservations"
              className="btn-premium glass-light text-gold px-10 py-4 rounded-full font-semibold tracking-wider uppercase hover:bg-gold/20 transition-all text-lg"
            >
              Book a Table
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
