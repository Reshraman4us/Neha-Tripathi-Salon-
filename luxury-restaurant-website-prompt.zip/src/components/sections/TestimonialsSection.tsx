"use client";

import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

interface Testimonial {
  id: number;
  name: string;
  role: string | null;
  content: string;
  rating: number;
  image: string | null;
  featured: boolean | null;
}

export default function TestimonialsSection({ testimonials }: { testimonials: Testimonial[] }) {
  const displayTestimonials = testimonials.filter(t => t.featured).slice(0, 6);

  if (displayTestimonials.length === 0) {
    return null;
  }

  return (
    <section id="testimonials" className="py-24 lg:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-dark" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-gold text-sm font-inter tracking-[0.2em] uppercase mb-4 block">Testimonials</span>
          <h2 className="font-playfair text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            <span className="text-cream">What Our </span>
            <span className="text-gradient">Guests Say</span>
          </h2>
          <p className="text-cream/50 font-inter max-w-2xl mx-auto">
            Don&apos;t just take our word for it — hear from the distinguished guests who&apos;ve experienced the AUREUM difference.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayTestimonials.map((t, i) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="glass rounded-2xl p-8 hover:border-gold/30 transition-all duration-500"
            >
              <Quote className="text-gold/30 mb-4" size={32} />
              <p className="text-cream/70 font-inter leading-relaxed mb-6 text-sm">
                &ldquo;{t.content}&rdquo;
              </p>
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, s) => (
                  <Star
                    key={s}
                    size={14}
                    className={s < t.rating ? "text-gold fill-gold" : "text-cream/20"}
                  />
                ))}
              </div>
              <div className="flex items-center gap-3">
                {t.image && (
                  <img
                    src={t.image}
                    alt={t.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-gold/30"
                  />
                )}
                <div>
                  <p className="text-cream font-playfair font-semibold">{t.name}</p>
                  {t.role && (
                    <p className="text-cream/40 text-xs font-inter">{t.role}</p>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
