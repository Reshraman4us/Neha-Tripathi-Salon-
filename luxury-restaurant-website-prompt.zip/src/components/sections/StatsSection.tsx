"use client";

import { motion } from "framer-motion";

const stats = [
  { value: "50K+", label: "Happy Guests Served" },
  { value: "200+", label: "Signature Dishes" },
  { value: "15+", label: "Award-Winning Chefs" },
  { value: "28", label: "Industry Awards" },
];

export default function StatsSection() {
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1920&q=80"
          alt="Restaurant interior"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal-dark/90 backdrop-blur-sm" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="text-center"
            >
              <p className="font-playfair text-4xl md:text-5xl font-bold text-gradient mb-2">{stat.value}</p>
              <p className="text-cream/50 text-sm font-inter uppercase tracking-wider">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
