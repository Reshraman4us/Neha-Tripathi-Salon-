"use client";

import Link from "next/link";
import { MapPin, Phone, Mail, Clock, ChevronRight } from "lucide-react";
import { useTheme } from "@/lib/theme-context";

export default function Footer() {
  const { theme } = useTheme();

  return (
    <footer className={`border-t border-gold/10 ${theme === "light" ? "bg-[#F0EBE0]" : "bg-charcoal-dark"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <Link href="/" className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-gradient-gold flex items-center justify-center text-charcoal-dark font-bold text-lg font-playfair">A</div>
              <span className="font-playfair text-2xl font-bold text-gradient tracking-wider">AUREUM</span>
            </Link>
            <p className="text-cream/50 text-sm leading-relaxed mb-6 font-inter">
              A world-class fine dining experience where culinary artistry meets timeless elegance. Every dish tells a story of passion and perfection.
            </p>
            <div className="flex gap-4">
              <a href="#" aria-label="Instagram" className="w-10 h-10 rounded-full glass-light flex items-center justify-center text-gold/70 hover:text-gold hover:bg-gold/20 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
              </a>
              <a href="#" aria-label="Facebook" className="w-10 h-10 rounded-full glass-light flex items-center justify-center text-gold/70 hover:text-gold hover:bg-gold/20 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
              </a>
              <a href="#" aria-label="X" className="w-10 h-10 rounded-full glass-light flex items-center justify-center text-gold/70 hover:text-gold hover:bg-gold/20 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4l11.733 16h4.267l-11.733 -16z"/><path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772"/></svg>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-playfair text-lg text-gold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {[
                { label: "Our Menu", href: "/menu" },
                { label: "Reservations", href: "/#reservations" },
                { label: "About Us", href: "/#about" },
                { label: "Gallery", href: "/#gallery" },
                { label: "Reviews", href: "/#testimonials" },
                { label: "Order Online", href: "/menu" },
                { label: "My Account", href: "/profile" },
                { label: "Sign In", href: "/login" },
              ].map((link) => (
                <li key={link.label}>
                  <Link href={link.href} className="text-cream/50 hover:text-gold transition-colors text-sm font-inter flex items-center gap-2">
                    <ChevronRight size={14} className="text-gold/40" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-playfair text-lg text-gold mb-6">Contact</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-gold/60 mt-0.5 shrink-0" />
                <span className="text-cream/50 text-sm font-inter">123 Fifth Avenue, Manhattan<br />New York, NY 10010</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-gold/60 shrink-0" />
                <a href="tel:+12125551234" className="text-cream/50 hover:text-gold text-sm font-inter transition-colors">(212) 555-1234</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-gold/60 shrink-0" />
                <a href="mailto:hello@aureum.com" className="text-cream/50 hover:text-gold text-sm font-inter transition-colors">hello@aureum.com</a>
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div>
            <h4 className="font-playfair text-lg text-gold mb-6">Opening Hours</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Clock size={18} className="text-gold/60 mt-0.5 shrink-0" />
                <div>
                  <p className="text-cream/70 text-sm font-medium font-inter">Mon - Thu</p>
                  <p className="text-cream/50 text-sm font-inter">5:00 PM - 11:00 PM</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Clock size={18} className="text-gold/60 mt-0.5 shrink-0" />
                <div>
                  <p className="text-cream/70 text-sm font-medium font-inter">Fri - Sat</p>
                  <p className="text-cream/50 text-sm font-inter">5:00 PM - 12:00 AM</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Clock size={18} className="text-gold/60 mt-0.5 shrink-0" />
                <div>
                  <p className="text-cream/70 text-sm font-medium font-inter">Sunday</p>
                  <p className="text-cream/50 text-sm font-inter">4:00 PM - 10:00 PM</p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="section-divider mt-12 mb-8" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-cream/30 text-sm font-inter">© 2026 AUREUM Fine Dining. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="text-cream/30 hover:text-gold/60 text-sm font-inter transition-colors">Privacy Policy</a>
            <a href="#" className="text-cream/30 hover:text-gold/60 text-sm font-inter transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
