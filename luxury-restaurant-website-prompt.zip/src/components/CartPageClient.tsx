"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft, CreditCard, CheckCircle2 } from "lucide-react";
import { getCart, updateQuantity, removeFromCart, clearCart, getCartTotal, type CartItem } from "@/lib/cart-store";

const TAX_RATE = 0.08875; // NYC tax
const tipOptions = [15, 18, 20, 25];

export default function CartPageClient() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [tipPercent, setTipPercent] = useState(18);
  const [customTip, setCustomTip] = useState("");
  const [promoCode, setPromoCode] = useState("");
  const [promoApplied, setPromoApplied] = useState(false);
  const [orderType, setOrderType] = useState<"delivery" | "pickup">("delivery");
  const [showCheckout, setShowCheckout] = useState(false);
  const [checkoutForm, setCheckoutForm] = useState({
    name: "", email: "", phone: "", address: "", notes: "", paymentMethod: "card",
  });
  const [submitting, setSubmitting] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);

  useEffect(() => {
    setCart(getCart());
    const handler = () => setCart(getCart());
    window.addEventListener("cart-updated", handler);
    return () => window.removeEventListener("cart-updated", handler);
  }, []);

  const subtotal = getCartTotal(cart);
  const discount = promoApplied ? subtotal * 0.1 : 0;
  const afterDiscount = subtotal - discount;
  const tax = afterDiscount * TAX_RATE;
  const tipAmount = customTip ? parseFloat(customTip) || 0 : afterDiscount * (tipPercent / 100);
  const total = afterDiscount + tax + tipAmount;

  const handleApplyPromo = () => {
    if (promoCode.toUpperCase() === "AUREUM10") {
      setPromoApplied(true);
    }
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: checkoutForm.name,
          customerEmail: checkoutForm.email,
          customerPhone: checkoutForm.phone,
          address: checkoutForm.address,
          orderType,
          items: cart,
          subtotal: subtotal.toFixed(2),
          tax: tax.toFixed(2),
          tip: tipAmount.toFixed(2),
          total: total.toFixed(2),
          promoCode: promoApplied ? promoCode : null,
          discount: discount.toFixed(2),
          notes: checkoutForm.notes,
          paymentMethod: checkoutForm.paymentMethod,
        }),
      });
      if (!res.ok) throw new Error("Order failed");
      clearCart();
      setCart([]);
      setOrderSuccess(true);
    } catch {
      // ignore
    } finally {
      setSubmitting(false);
    }
  };

  if (orderSuccess) {
    return (
      <div className="pt-32 pb-24 min-h-screen flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass rounded-3xl p-12 text-center max-w-lg mx-4"
        >
          <CheckCircle2 className="mx-auto text-gold mb-6" size={72} />
          <h2 className="font-playfair text-4xl font-bold text-cream mb-4">Order Placed!</h2>
          <p className="text-cream/60 font-inter mb-2">Your order has been confirmed and is being prepared.</p>
          <p className="text-cream/40 font-inter text-sm mb-8">You will receive a confirmation email shortly with your order details and estimated delivery time.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/menu" className="btn-premium bg-gradient-gold text-charcoal-dark px-8 py-3 rounded-full font-semibold tracking-wider uppercase">
              Order More
            </Link>
            <Link href="/" className="btn-premium glass-light text-gold px-8 py-3 rounded-full font-semibold tracking-wider uppercase hover:bg-gold/20 transition-all">
              Go Home
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="pt-32 pb-24 min-h-screen flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-lg mx-4"
        >
          <ShoppingBag className="mx-auto text-gold/30 mb-6" size={72} />
          <h2 className="font-playfair text-3xl font-bold text-cream mb-4">Your Cart is Empty</h2>
          <p className="text-cream/50 font-inter mb-8">Explore our exquisite menu and add your favorites.</p>
          <Link href="/menu" className="btn-premium bg-gradient-gold text-charcoal-dark px-8 py-4 rounded-full font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all">
            Browse Menu
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/menu" className="text-cream/40 hover:text-gold transition-colors">
            <ArrowLeft size={24} />
          </Link>
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-cream">
            Your <span className="text-gradient">Cart</span>
          </h1>
          <span className="text-cream/40 font-inter text-sm">({cart.length} items)</span>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {/* Order Type Toggle */}
            <div className="glass rounded-2xl p-4 flex gap-2">
              <button
                onClick={() => setOrderType("delivery")}
                className={`flex-1 py-3 rounded-xl text-sm font-semibold tracking-wider uppercase transition-all ${
                  orderType === "delivery" ? "bg-gradient-gold text-charcoal-dark" : "text-cream/50 hover:text-gold"
                }`}
              >
                🚗 Delivery
              </button>
              <button
                onClick={() => setOrderType("pickup")}
                className={`flex-1 py-3 rounded-xl text-sm font-semibold tracking-wider uppercase transition-all ${
                  orderType === "pickup" ? "bg-gradient-gold text-charcoal-dark" : "text-cream/50 hover:text-gold"
                }`}
              >
                🏪 Pickup
              </button>
            </div>

            {cart.map((item) => (
              <motion.div
                key={item.id}
                layout
                className="glass rounded-2xl p-4 flex gap-4"
              >
                <img
                  src={item.image || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200"}
                  alt={item.name}
                  className="w-24 h-24 rounded-xl object-cover shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-playfair text-lg font-semibold text-cream truncate">{item.name}</h3>
                  <p className="text-gold font-semibold text-lg">${item.price}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-8 h-8 rounded-full glass-light flex items-center justify-center text-cream/60 hover:text-gold transition-colors"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="text-cream font-semibold w-8 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 rounded-full glass-light flex items-center justify-center text-cream/60 hover:text-gold transition-colors"
                    >
                      <Plus size={14} />
                    </button>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="ml-auto text-red-400/60 hover:text-red-400 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-gold font-bold text-lg">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="space-y-6">
            <div className="glass rounded-2xl p-6">
              <h3 className="font-playfair text-xl font-bold text-cream mb-6">Order Summary</h3>

              {/* Promo Code */}
              <div className="flex gap-2 mb-6">
                <input
                  type="text"
                  placeholder="Promo code"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  disabled={promoApplied}
                  className="flex-1 bg-charcoal/50 border border-gold/20 rounded-xl px-4 py-2.5 text-cream text-sm font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors disabled:opacity-50"
                />
                <button
                  onClick={handleApplyPromo}
                  disabled={promoApplied}
                  className="px-4 py-2.5 rounded-xl bg-gold/20 text-gold text-sm font-semibold hover:bg-gold/30 transition-colors disabled:opacity-50"
                >
                  {promoApplied ? "Applied!" : "Apply"}
                </button>
              </div>

              {/* Tip Selection */}
              <div className="mb-6">
                <p className="text-cream/60 text-sm font-inter mb-3">Add a tip for our team</p>
                <div className="grid grid-cols-4 gap-2 mb-2">
                  {tipOptions.map((t) => (
                    <button
                      key={t}
                      onClick={() => { setTipPercent(t); setCustomTip(""); }}
                      className={`py-2 rounded-lg text-sm font-semibold transition-all ${
                        tipPercent === t && !customTip ? "bg-gradient-gold text-charcoal-dark" : "glass-light text-cream/60 hover:text-gold"
                      }`}
                    >
                      {t}%
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  placeholder="Custom tip amount"
                  value={customTip}
                  onChange={(e) => setCustomTip(e.target.value)}
                  className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-4 py-2.5 text-cream text-sm font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                />
              </div>

              <div className="section-divider mb-4" />

              {/* Price Breakdown */}
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-cream/60 font-inter text-sm">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                {promoApplied && (
                  <div className="flex justify-between text-green-400 font-inter text-sm">
                    <span>Discount (10%)</span>
                    <span>-${discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-cream/60 font-inter text-sm">
                  <span>Tax (8.875%)</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-cream/60 font-inter text-sm">
                  <span>Tip</span>
                  <span>${tipAmount.toFixed(2)}</span>
                </div>
                <div className="section-divider" />
                <div className="flex justify-between text-cream font-semibold text-lg">
                  <span>Total</span>
                  <span className="text-gold">${total.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={() => setShowCheckout(true)}
                className="w-full btn-premium bg-gradient-gold text-charcoal-dark py-4 rounded-full font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all flex items-center justify-center gap-2"
              >
                <CreditCard size={18} />
                Proceed to Checkout
              </button>

              <p className="text-cream/20 text-xs font-inter mt-3 text-center">
                Try promo code: AUREUM10 for 10% off
              </p>
            </div>
          </div>
        </div>

        {/* Checkout Modal */}
        {showCheckout && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="glass rounded-3xl p-8 max-w-lg w-full max-h-[90vh] overflow-y-auto"
            >
              <h3 className="font-playfair text-2xl font-bold text-cream mb-6">Checkout</h3>

              <form onSubmit={handlePlaceOrder} className="space-y-4">
                <div>
                  <label className="block text-cream/70 text-sm font-inter mb-1 tracking-wider uppercase">Full Name *</label>
                  <input
                    type="text" required
                    value={checkoutForm.name}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, name: e.target.value })}
                    className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                    placeholder="John Smith"
                  />
                </div>
                <div>
                  <label className="block text-cream/70 text-sm font-inter mb-1 tracking-wider uppercase">Email *</label>
                  <input
                    type="email" required
                    value={checkoutForm.email}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, email: e.target.value })}
                    className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                    placeholder="john@example.com"
                  />
                </div>
                <div>
                  <label className="block text-cream/70 text-sm font-inter mb-1 tracking-wider uppercase">Phone *</label>
                  <input
                    type="tel" required
                    value={checkoutForm.phone}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, phone: e.target.value })}
                    className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                    placeholder="(212) 555-1234"
                  />
                </div>
                {orderType === "delivery" && (
                  <div>
                    <label className="block text-cream/70 text-sm font-inter mb-1 tracking-wider uppercase">Delivery Address *</label>
                    <input
                      type="text" required
                      value={checkoutForm.address}
                      onChange={(e) => setCheckoutForm({ ...checkoutForm, address: e.target.value })}
                      className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                      placeholder="123 Main St, Apt 4, NYC"
                    />
                  </div>
                )}
                <div>
                  <label className="block text-cream/70 text-sm font-inter mb-1 tracking-wider uppercase">Payment Method</label>
                  <select
                    value={checkoutForm.paymentMethod}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, paymentMethod: e.target.value })}
                    className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3 text-cream font-inter focus:outline-none focus:border-gold/60 transition-colors"
                  >
                    <option value="card">💳 Credit/Debit Card</option>
                    <option value="apple_pay">🍎 Apple Pay</option>
                    <option value="google_pay">📱 Google Pay</option>
                    <option value="paypal">🅿️ PayPal</option>
                    <option value="cash">💵 Cash on Delivery</option>
                  </select>
                </div>
                <div>
                  <label className="block text-cream/70 text-sm font-inter mb-1 tracking-wider uppercase">Order Notes</label>
                  <textarea
                    rows={2}
                    value={checkoutForm.notes}
                    onChange={(e) => setCheckoutForm({ ...checkoutForm, notes: e.target.value })}
                    className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-5 py-3 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors resize-none"
                    placeholder="Special instructions..."
                  />
                </div>

                <div className="section-divider my-4" />

                <div className="flex justify-between text-cream font-semibold text-lg mb-4">
                  <span>Total</span>
                  <span className="text-gold">${total.toFixed(2)}</span>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowCheckout(false)}
                    className="flex-1 glass-light text-cream/60 py-3.5 rounded-full font-semibold tracking-wider uppercase hover:text-gold transition-colors"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 btn-premium bg-gradient-gold text-charcoal-dark py-3.5 rounded-full font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all disabled:opacity-50"
                  >
                    {submitting ? "Processing..." : "Place Order"}
                  </button>
                </div>

                <p className="text-cream/20 text-xs font-inter text-center mt-2">
                  🔒 Secure checkout • SSL encrypted
                </p>
              </form>
            </motion.div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
