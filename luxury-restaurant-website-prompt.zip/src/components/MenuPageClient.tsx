"use client";

import { useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Star, Flame, Leaf, ShoppingBag, Search, SlidersHorizontal, Heart } from "lucide-react";
import { addToCart } from "@/lib/cart-store";
import { useAuth } from "@/lib/auth-context";

interface Category {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  image: string | null;
}

interface MenuItem {
  id: number;
  categoryId: number;
  name: string;
  slug: string;
  description: string | null;
  price: number;
  image: string | null;
  calories: number | null;
  ingredients: string | null;
  isVegan: boolean | null;
  isSpicy: boolean | null;
  isPopular: boolean | null;
  isNew: boolean | null;
  rating: number | null;
  reviewCount: number | null;
}

interface Props {
  categories: Category[];
  items: MenuItem[];
}

export default function MenuPageClient({ categories, items }: Props) {
  const searchParams = useSearchParams();
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<"default" | "price-low" | "price-high" | "rating">("default");
  const [addedId, setAddedId] = useState<number | null>(null);
  const { user, toggleFavorite } = useAuth();

  // Handle ?category= from URL
  useEffect(() => {
    const cat = searchParams.get("category");
    if (cat && categories.some((c) => c.slug === cat)) {
      setActiveCategory(cat);
    }
  }, [searchParams, categories]);

  let filtered = activeCategory === "all"
    ? items
    : items.filter((item) => {
        const cat = categories.find((c) => c.slug === activeCategory);
        return cat && item.categoryId === cat.id;
      });

  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(
      (item) =>
        item.name.toLowerCase().includes(q) ||
        (item.description && item.description.toLowerCase().includes(q)) ||
        (item.ingredients && item.ingredients.toLowerCase().includes(q))
    );
  }

  if (sortBy === "price-low") filtered = [...filtered].sort((a, b) => a.price - b.price);
  if (sortBy === "price-high") filtered = [...filtered].sort((a, b) => b.price - a.price);
  if (sortBy === "rating") filtered = [...filtered].sort((a, b) => (b.rating || 0) - (a.rating || 0));

  const handleAddToCart = (item: MenuItem) => {
    addToCart({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image || "",
    });
    setAddedId(item.id);
    setTimeout(() => setAddedId(null), 1200);
  };

  const isFav = (id: number) => user?.favorites?.includes(id) ?? false;

  return (
    <div className="pt-24 pb-16">
      {/* Hero */}
      <div className="relative h-[300px] md:h-[400px] mb-12 overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1920&q=80"
          alt="Our menu"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal-dark/80" />
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
            <span className="text-gold text-sm font-inter tracking-[0.2em] uppercase mb-4 block">Explore</span>
            <h1 className="font-playfair text-5xl md:text-6xl lg:text-7xl font-bold mb-4">
              <span className="text-cream">Our </span>
              <span className="text-gradient">Menu</span>
            </h1>
            <p className="text-cream/50 font-inter max-w-xl mx-auto">
              Every dish is a masterpiece, crafted with the finest ingredients and presented with artistic precision.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Search & Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-cream/30" size={20} />
            <input
              type="text"
              placeholder="Search dishes, ingredients..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-charcoal/50 border border-gold/20 rounded-xl pl-12 pr-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
            />
          </div>
          <div className="relative">
            <SlidersHorizontal className="absolute left-4 top-1/2 -translate-y-1/2 text-cream/30" size={20} />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="bg-charcoal/50 border border-gold/20 rounded-xl pl-12 pr-8 py-3.5 text-cream font-inter focus:outline-none focus:border-gold/60 transition-colors appearance-none"
            >
              <option value="default">Default</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="rating">Top Rated</option>
            </select>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap gap-3 mb-10 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-6 py-2.5 rounded-full text-sm font-inter tracking-wider uppercase transition-all whitespace-nowrap ${
              activeCategory === "all" ? "bg-gradient-gold text-charcoal-dark font-semibold" : "glass-light text-cream/60 hover:text-gold"
            }`}
          >
            All Dishes
          </button>
          {categories.map((cat) => (
            <button
              key={cat.slug}
              onClick={() => setActiveCategory(cat.slug)}
              className={`px-6 py-2.5 rounded-full text-sm font-inter tracking-wider uppercase transition-all whitespace-nowrap ${
                activeCategory === cat.slug ? "bg-gradient-gold text-charcoal-dark font-semibold" : "glass-light text-cream/60 hover:text-gold"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Items Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <AnimatePresence mode="popLayout">
            {filtered.map((item, i) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3, delay: i * 0.03 }}
                className="group menu-card-hover glass rounded-2xl overflow-hidden"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={item.image || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500"}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal-dark/80 to-transparent" />

                  <div className="absolute top-3 left-3 flex gap-2">
                    {item.isNew && (
                      <span className="px-2 py-1 rounded-full bg-warm-orange/90 text-white text-xs font-semibold">NEW</span>
                    )}
                    {item.isSpicy && (
                      <span className="px-2 py-1 rounded-full bg-wine/90 text-white text-xs font-semibold flex items-center gap-1">
                        <Flame size={10} /> Spicy
                      </span>
                    )}
                    {item.isVegan && (
                      <span className="px-2 py-1 rounded-full bg-green-600/90 text-white text-xs font-semibold flex items-center gap-1">
                        <Leaf size={10} /> Vegan
                      </span>
                    )}
                  </div>

                  {/* Favorite + Add to Cart */}
                  <div className="absolute top-3 right-3 flex flex-col gap-2">
                    {user && (
                      <button
                        onClick={() => toggleFavorite(item.id)}
                        className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg ${
                          isFav(item.id) ? "bg-red-500 text-white" : "bg-white/90 text-charcoal opacity-0 group-hover:opacity-100"
                        }`}
                      >
                        <Heart size={18} className={isFav(item.id) ? "fill-white" : ""} />
                      </button>
                    )}
                    <button
                      onClick={() => handleAddToCart(item)}
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg ${
                        addedId === item.id
                          ? "bg-green-500 text-white scale-110"
                          : "bg-gold text-charcoal-dark opacity-0 group-hover:opacity-100 hover:scale-110"
                      }`}
                    >
                      {addedId === item.id ? "✓" : <ShoppingBag size={18} />}
                    </button>
                  </div>

                  <div className="absolute bottom-3 right-3 bg-gold text-charcoal-dark px-4 py-1.5 rounded-full text-sm font-bold">
                    ${item.price}
                  </div>
                </div>

                <div className="p-5">
                  <h3 className="font-playfair text-lg font-semibold text-cream mb-1 group-hover:text-gold transition-colors">
                    {item.name}
                  </h3>
                  <p className="text-cream/40 text-sm font-inter line-clamp-2 mb-3">{item.description}</p>

                  {item.ingredients && (
                    <p className="text-cream/25 text-xs font-inter mb-3 line-clamp-2">
                      {item.ingredients}
                    </p>
                  )}

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Star size={14} className="text-gold fill-gold" />
                      <span className="text-gold text-sm font-semibold">{item.rating}</span>
                      <span className="text-cream/30 text-xs">({item.reviewCount})</span>
                    </div>
                    {item.calories && (
                      <span className="text-cream/30 text-xs font-inter">{item.calories} cal</span>
                    )}
                  </div>

                  <button
                    onClick={() => handleAddToCart(item)}
                    className={`mt-4 w-full py-2.5 rounded-xl text-sm font-semibold tracking-wider uppercase transition-all flex items-center justify-center gap-2 ${
                      addedId === item.id
                        ? "bg-green-500/20 text-green-400 border border-green-500/30"
                        : "btn-premium glass-light text-gold hover:bg-gold/20"
                    }`}
                  >
                    {addedId === item.id ? (
                      <>✓ Added to Cart</>
                    ) : (
                      <><ShoppingBag size={16} /> Add to Cart</>
                    )}
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20">
            <p className="text-cream/40 font-inter text-lg">No dishes found. Try a different search or category.</p>
          </div>
        )}
      </div>
    </div>
  );
}
