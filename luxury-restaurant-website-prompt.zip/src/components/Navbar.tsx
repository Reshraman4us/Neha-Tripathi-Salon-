"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu, X, ShoppingBag, Phone, User, LogOut, ChevronDown,
  Sun, Moon, Heart, Clock, Settings, Star, Award,
  Utensils, Beef, Fish, Pizza, CakeSlice, Wine, Salad, Flame as FlameIcon,
} from "lucide-react";
import { getCart, type CartItem } from "@/lib/cart-store";
import { useTheme } from "@/lib/theme-context";
import { useAuth } from "@/lib/auth-context";

const navLinks = [
  { href: "/#home", label: "Home" },
  { href: "/#about", label: "About" },
  { href: "/menu", label: "Menu", hasDropdown: true },
  { href: "/#reservations", label: "Reservations" },
  { href: "/#gallery", label: "Gallery" },
  { href: "/#testimonials", label: "Reviews" },
  { href: "/#contact", label: "Contact" },
];

const categoryLinks = [
  { slug: "starters", label: "Starters", icon: Utensils },
  { slug: "main-course", label: "Main Course", icon: Utensils },
  { slug: "seafood", label: "Seafood", icon: Fish },
  { slug: "steaks", label: "Steaks", icon: Beef },
  { slug: "pizza-pasta", label: "Pizza & Pasta", icon: Pizza },
  { slug: "burgers", label: "Burgers", icon: FlameIcon },
  { slug: "desserts", label: "Desserts", icon: CakeSlice },
  { slug: "drinks", label: "Drinks", icon: Wine },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [showCategories, setShowCategories] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const catRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    const onCart = () => {
      const items = getCart();
      setCartCount(items.reduce((s: number, i: CartItem) => s + i.quantity, 0));
    };
    onCart();
    window.addEventListener("scroll", onScroll);
    window.addEventListener("cart-updated", onCart);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("cart-updated", onCart);
    };
  }, []);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (catRef.current && !catRef.current.contains(e.target as Node)) setShowCategories(false);
      if (userRef.current && !userRef.current.contains(e.target as Node)) setShowUserMenu(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const handleLogout = () => {
    logout();
    setShowUserMenu(false);
  };

  const initials = user?.name ? user.name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2) : "";

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "glass shadow-2xl shadow-black/30" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group shrink-0">
            <div className="w-10 h-10 rounded-full bg-gradient-gold flex items-center justify-center text-charcoal-dark font-bold text-lg font-playfair group-hover:scale-110 transition-transform">
              A
            </div>
            <span className="font-playfair text-2xl font-bold text-gradient tracking-wider hidden sm:inline">
              AUREUM
            </span>
          </Link>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) =>
              link.hasDropdown ? (
                <div key={link.label} className="relative" ref={catRef}>
                  <button
                    onClick={() => setShowCategories(!showCategories)}
                    className="flex items-center gap-1 px-3 py-2 text-sm font-medium text-cream/70 hover:text-gold transition-colors duration-300 tracking-wider uppercase font-inter rounded-lg hover:bg-gold/5"
                  >
                    {link.label}
                    <ChevronDown
                      size={14}
                      className={`transition-transform duration-300 ${showCategories ? "rotate-180" : ""}`}
                    />
                  </button>

                  {/* Mega Menu Dropdown */}
                  <AnimatePresence>
                    {showCategories && (
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        transition={{ duration: 0.2 }}
                        className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-[420px] glass rounded-2xl p-5 shadow-2xl shadow-black/40"
                      >
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-playfair text-gold text-lg font-semibold">Categories</h3>
                          <Link
                            href="/menu"
                            onClick={() => setShowCategories(false)}
                            className="text-xs text-gold/60 hover:text-gold font-inter tracking-wider uppercase transition-colors"
                          >
                            View All →
                          </Link>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          {categoryLinks.map((cat) => (
                            <Link
                              key={cat.slug}
                              href={`/menu?category=${cat.slug}`}
                              onClick={() => setShowCategories(false)}
                              className="flex items-center gap-3 p-3 rounded-xl hover:bg-gold/10 transition-all group/cat"
                            >
                              <div className="w-9 h-9 rounded-lg bg-gold/10 flex items-center justify-center shrink-0 group-hover/cat:bg-gold/20 transition-colors">
                                <cat.icon size={18} className="text-gold" />
                              </div>
                              <span className="text-sm text-cream/70 group-hover/cat:text-gold font-inter font-medium transition-colors">
                                {cat.label}
                              </span>
                            </Link>
                          ))}
                        </div>
                        <div className="section-divider mt-4 mb-3" />
                        <div className="flex gap-3">
                          <Link
                            href="/menu"
                            onClick={() => setShowCategories(false)}
                            className="flex-1 text-center text-xs py-2.5 rounded-xl bg-gradient-gold text-charcoal-dark font-semibold tracking-wider uppercase hover:shadow-lg hover:shadow-gold/20 transition-all"
                          >
                            Full Menu
                          </Link>
                          <Link
                            href="/cart"
                            onClick={() => setShowCategories(false)}
                            className="flex-1 text-center text-xs py-2.5 rounded-xl glass-light text-gold font-semibold tracking-wider uppercase hover:bg-gold/15 transition-all"
                          >
                            Order Online
                          </Link>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <Link
                  key={link.label}
                  href={link.href}
                  className="px-3 py-2 text-sm font-medium text-cream/70 hover:text-gold transition-colors duration-300 tracking-wider uppercase font-inter rounded-lg hover:bg-gold/5"
                >
                  {link.label}
                </Link>
              )
            )}
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="relative w-10 h-10 rounded-full glass-light flex items-center justify-center text-cream/60 hover:text-gold hover:bg-gold/15 transition-all group"
              aria-label="Toggle theme"
            >
              <AnimatePresence mode="wait">
                {theme === "dark" ? (
                  <motion.div
                    key="sun"
                    initial={{ rotate: -90, scale: 0 }}
                    animate={{ rotate: 0, scale: 1 }}
                    exit={{ rotate: 90, scale: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Sun size={18} className="group-hover:rotate-45 transition-transform duration-500" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="moon"
                    initial={{ rotate: 90, scale: 0 }}
                    animate={{ rotate: 0, scale: 1 }}
                    exit={{ rotate: -90, scale: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Moon size={18} className="group-hover:-rotate-12 transition-transform duration-500" />
                  </motion.div>
                )}
              </AnimatePresence>
            </button>

            {/* Cart */}
            <Link
              href="/cart"
              className="relative w-10 h-10 rounded-full glass-light flex items-center justify-center text-cream/60 hover:text-gold hover:bg-gold/15 transition-all"
            >
              <ShoppingBag size={18} />
              {cartCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-gold rounded-full text-charcoal-dark text-[10px] font-bold flex items-center justify-center shadow-lg"
                >
                  {cartCount > 99 ? "99+" : cartCount}
                </motion.span>
              )}
            </Link>

            {/* User Profile / Login */}
            <div className="relative" ref={userRef}>
              {user ? (
                <>
                  <button
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="flex items-center gap-2 h-10 pl-1 pr-3 rounded-full glass-light hover:bg-gold/15 transition-all group"
                  >
                    <div className="w-8 h-8 rounded-full bg-gradient-gold flex items-center justify-center text-charcoal-dark text-xs font-bold font-playfair">
                      {initials}
                    </div>
                    <span className="hidden md:inline text-sm text-cream/70 group-hover:text-gold font-inter font-medium transition-colors max-w-[80px] truncate">
                      {user.name.split(" ")[0]}
                    </span>
                    <ChevronDown
                      size={12}
                      className={`hidden md:block text-cream/40 transition-transform duration-300 ${showUserMenu ? "rotate-180" : ""}`}
                    />
                  </button>

                  <AnimatePresence>
                    {showUserMenu && (
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        transition={{ duration: 0.2 }}
                        className="absolute right-0 top-full mt-2 w-72 glass rounded-2xl p-4 shadow-2xl shadow-black/40"
                      >
                        {/* User Info Header */}
                        <div className="flex items-center gap-3 mb-4 pb-4 border-b border-gold/10">
                          <div className="w-12 h-12 rounded-full bg-gradient-gold flex items-center justify-center text-charcoal-dark text-lg font-bold font-playfair">
                            {initials}
                          </div>
                          <div className="min-w-0">
                            <p className="text-cream font-playfair font-semibold truncate">{user.name}</p>
                            <p className="text-cream/40 text-xs font-inter truncate">{user.email}</p>
                            <div className="flex items-center gap-1 mt-1">
                              <Award size={10} className="text-gold" />
                              <span className="text-gold text-[10px] font-inter uppercase tracking-wider font-semibold">
                                {user.memberTier} Member
                              </span>
                              <span className="text-cream/30 text-[10px] font-inter ml-1">
                                • {user.loyaltyPoints} pts
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Menu Items */}
                        <div className="space-y-1">
                          <Link
                            href="/profile"
                            onClick={() => setShowUserMenu(false)}
                            className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gold/10 transition-all text-cream/70 hover:text-gold"
                          >
                            <User size={16} />
                            <span className="text-sm font-inter">My Profile</span>
                          </Link>
                          <Link
                            href="/profile?tab=orders"
                            onClick={() => setShowUserMenu(false)}
                            className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gold/10 transition-all text-cream/70 hover:text-gold"
                          >
                            <Clock size={16} />
                            <span className="text-sm font-inter">Order History</span>
                          </Link>
                          <Link
                            href="/profile?tab=favorites"
                            onClick={() => setShowUserMenu(false)}
                            className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gold/10 transition-all text-cream/70 hover:text-gold"
                          >
                            <Heart size={16} />
                            <span className="text-sm font-inter">Favorites</span>
                          </Link>
                          <Link
                            href="/profile?tab=reservations"
                            onClick={() => setShowUserMenu(false)}
                            className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gold/10 transition-all text-cream/70 hover:text-gold"
                          >
                            <Star size={16} />
                            <span className="text-sm font-inter">Reservations</span>
                          </Link>
                          <Link
                            href="/profile?tab=settings"
                            onClick={() => setShowUserMenu(false)}
                            className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gold/10 transition-all text-cream/70 hover:text-gold"
                          >
                            <Settings size={16} />
                            <span className="text-sm font-inter">Settings</span>
                          </Link>
                        </div>

                        <div className="section-divider mt-3 mb-3" />

                        <button
                          onClick={handleLogout}
                          className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-red-500/10 transition-all text-red-400/70 hover:text-red-400 w-full"
                        >
                          <LogOut size={16} />
                          <span className="text-sm font-inter">Sign Out</span>
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </>
              ) : (
                <Link
                  href="/login"
                  className="flex items-center gap-2 h-10 px-4 rounded-full glass-light text-cream/60 hover:text-gold hover:bg-gold/15 transition-all"
                >
                  <User size={18} />
                  <span className="hidden md:inline text-sm font-inter font-medium tracking-wider">Login</span>
                </Link>
              )}
            </div>

            {/* Phone — only large screens */}
            <a
              href="tel:+12125551234"
              className="hidden xl:flex items-center gap-2 text-sm text-cream/60 hover:text-gold transition-colors ml-1"
            >
              <Phone size={15} />
              <span className="font-inter">(212) 555-1234</span>
            </a>

            {/* Book Table CTA */}
            <Link
              href="/#reservations"
              className="hidden md:inline-flex btn-premium bg-gradient-gold text-charcoal-dark px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase hover:shadow-lg hover:shadow-gold/30 transition-all"
            >
              Book Table
            </Link>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="lg:hidden w-10 h-10 rounded-full glass-light flex items-center justify-center text-cream/60 hover:text-gold transition-colors"
            >
              {isOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="lg:hidden glass border-t border-gold/10 overflow-hidden"
          >
            <div className="px-4 py-6 space-y-2 max-h-[80vh] overflow-y-auto">
              {/* User info in mobile */}
              {user && (
                <div className="flex items-center gap-3 mb-4 pb-4 border-b border-gold/10">
                  <div className="w-10 h-10 rounded-full bg-gradient-gold flex items-center justify-center text-charcoal-dark text-sm font-bold font-playfair">
                    {initials}
                  </div>
                  <div>
                    <p className="text-cream font-playfair font-semibold text-sm">{user.name}</p>
                    <div className="flex items-center gap-1">
                      <Award size={10} className="text-gold" />
                      <span className="text-gold text-[10px] font-inter uppercase tracking-wider font-semibold">
                        {user.memberTier}
                      </span>
                      <span className="text-cream/30 text-[10px]">• {user.loyaltyPoints} pts</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Nav links */}
              {navLinks.map((link) => (
                <div key={link.label}>
                  <Link
                    href={link.href}
                    onClick={() => { if (!link.hasDropdown) setIsOpen(false); }}
                    className="flex items-center justify-between py-3 px-3 rounded-xl text-cream/80 hover:text-gold hover:bg-gold/5 transition-all font-medium tracking-wider uppercase text-sm"
                  >
                    {link.label}
                    {link.hasDropdown && <ChevronDown size={14} className="text-cream/30" />}
                  </Link>
                  {link.hasDropdown && (
                    <div className="grid grid-cols-2 gap-1 ml-3 mt-1">
                      {categoryLinks.map((cat) => (
                        <Link
                          key={cat.slug}
                          href={`/menu?category=${cat.slug}`}
                          onClick={() => setIsOpen(false)}
                          className="flex items-center gap-2 py-2 px-3 rounded-lg text-cream/50 hover:text-gold hover:bg-gold/5 transition-all text-xs font-inter"
                        >
                          <cat.icon size={14} className="text-gold/50" />
                          {cat.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              <div className="section-divider my-3" />

              {/* Mobile actions */}
              {user ? (
                <div className="space-y-1">
                  <Link href="/profile" onClick={() => setIsOpen(false)} className="flex items-center gap-3 py-2.5 px-3 rounded-xl text-cream/70 hover:text-gold hover:bg-gold/5 transition-all text-sm font-inter">
                    <User size={16} /> My Profile
                  </Link>
                  <Link href="/profile?tab=orders" onClick={() => setIsOpen(false)} className="flex items-center gap-3 py-2.5 px-3 rounded-xl text-cream/70 hover:text-gold hover:bg-gold/5 transition-all text-sm font-inter">
                    <Clock size={16} /> Order History
                  </Link>
                  <Link href="/profile?tab=favorites" onClick={() => setIsOpen(false)} className="flex items-center gap-3 py-2.5 px-3 rounded-xl text-cream/70 hover:text-gold hover:bg-gold/5 transition-all text-sm font-inter">
                    <Heart size={16} /> Favorites
                  </Link>
                  <button onClick={() => { handleLogout(); setIsOpen(false); }} className="flex items-center gap-3 py-2.5 px-3 rounded-xl text-red-400/70 hover:text-red-400 hover:bg-red-500/5 transition-all text-sm font-inter w-full">
                    <LogOut size={16} /> Sign Out
                  </button>
                </div>
              ) : (
                <Link
                  href="/login"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center justify-center gap-2 w-full py-3 rounded-xl glass-light text-gold font-semibold tracking-wider uppercase text-sm hover:bg-gold/15 transition-all"
                >
                  <User size={16} />
                  Sign In / Register
                </Link>
              )}

              {/* Theme toggle mobile */}
              <button
                onClick={toggleTheme}
                className="flex items-center gap-3 py-2.5 px-3 rounded-xl text-cream/70 hover:text-gold hover:bg-gold/5 transition-all text-sm font-inter w-full"
              >
                {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
                {theme === "dark" ? "Light Mode" : "Dark Mode"}
              </button>

              <Link
                href="/#reservations"
                onClick={() => setIsOpen(false)}
                className="block w-full text-center btn-premium bg-gradient-gold text-charcoal-dark px-6 py-3.5 rounded-full font-semibold tracking-wider uppercase mt-3"
              >
                Reserve Now
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
