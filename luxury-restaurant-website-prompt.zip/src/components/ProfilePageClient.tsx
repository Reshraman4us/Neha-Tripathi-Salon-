"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import {
  User, Clock, Heart, Star, Settings, Award, ShoppingBag,
  MapPin, Phone, Mail, Edit3, Save, ChevronRight, Gift,
  Crown, CalendarDays, Package, LogOut,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";

type Tab = "profile" | "orders" | "favorites" | "reservations" | "settings";

interface OrderRecord {
  id: number;
  items: { name: string; quantity: number; price: number }[];
  total: number;
  status: string | null;
  orderType: string | null;
  createdAt: string | null;
}

interface ReservationRecord {
  id: number;
  date: string;
  time: string;
  guests: number;
  occasion: string | null;
  status: string | null;
  createdAt: string | null;
}

const tabConfig: { key: Tab; label: string; icon: typeof User }[] = [
  { key: "profile", label: "Profile", icon: User },
  { key: "orders", label: "Orders", icon: Package },
  { key: "favorites", label: "Favorites", icon: Heart },
  { key: "reservations", label: "Reservations", icon: CalendarDays },
  { key: "settings", label: "Settings", icon: Settings },
];

const tierConfig: Record<string, { color: string; next: string; pointsNeeded: number }> = {
  bronze: { color: "from-amber-700 to-amber-500", next: "Silver", pointsNeeded: 500 },
  silver: { color: "from-gray-400 to-gray-300", next: "Gold", pointsNeeded: 2000 },
  gold: { color: "from-yellow-500 to-yellow-300", next: "Platinum", pointsNeeded: 5000 },
  platinum: { color: "from-purple-400 to-pink-300", next: "Diamond", pointsNeeded: 10000 },
  diamond: { color: "from-blue-400 to-cyan-300", next: "", pointsNeeded: 999999 },
};

export default function ProfilePageClient() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, logout, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>("profile");
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [reservations, setReservations] = useState<ReservationRecord[]>([]);
  const [editing, setEditing] = useState(false);
  const [formName, setFormName] = useState("");
  const [formPhone, setFormPhone] = useState("");
  const [formAddress, setFormAddress] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const tab = searchParams.get("tab") as Tab | null;
    if (tab && tabConfig.some((t) => t.key === tab)) setActiveTab(tab);
  }, [searchParams]);

  useEffect(() => {
    if (!user) {
      router.push("/login");
      return;
    }
    setFormName(user.name);
    setFormPhone(user.phone || "");
    setFormAddress(user.address || "");
  }, [user, router]);

  const fetchOrders = useCallback(async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/auth/orders?userId=${user.id}`);
      const data = await res.json();
      setOrders(Array.isArray(data) ? data : []);
    } catch { /* ignore */ }
  }, [user]);

  const fetchReservations = useCallback(async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/auth/reservations?userId=${user.id}`);
      const data = await res.json();
      setReservations(Array.isArray(data) ? data : []);
    } catch { /* ignore */ }
  }, [user]);

  useEffect(() => {
    if (activeTab === "orders") fetchOrders();
    if (activeTab === "reservations") fetchReservations();
  }, [activeTab, fetchOrders, fetchReservations]);

  const handleSaveProfile = async () => {
    setSaving(true);
    await updateProfile({ name: formName, phone: formPhone, address: formAddress });
    setEditing(false);
    setSaving(false);
  };

  if (!user) return null;

  const tier = tierConfig[user.memberTier] || tierConfig.bronze;
  const progress = Math.min((user.loyaltyPoints / tier.pointsNeeded) * 100, 100);

  const statusColor = (status: string | null) => {
    switch (status) {
      case "confirmed": case "completed": case "delivered": return "text-green-400 bg-green-500/10";
      case "pending": return "text-yellow-400 bg-yellow-500/10";
      case "cancelled": return "text-red-400 bg-red-500/10";
      default: return "text-cream/50 bg-cream/5";
    }
  };

  return (
    <div className="pt-28 pb-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-3xl p-6 md:p-8 mb-8"
        >
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="w-20 h-20 rounded-2xl bg-gradient-gold flex items-center justify-center text-charcoal-dark text-2xl font-bold font-playfair shrink-0">
              {user.name.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2)}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="font-playfair text-2xl md:text-3xl font-bold text-cream mb-1">{user.name}</h1>
              <p className="text-cream/50 font-inter text-sm">{user.email}</p>
              <div className="flex flex-wrap items-center gap-3 mt-3">
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r ${tier.color} text-charcoal-dark uppercase tracking-wider`}>
                  <Crown size={12} />
                  {user.memberTier} Member
                </span>
                <span className="text-cream/40 text-xs font-inter">{user.loyaltyPoints} loyalty points</span>
              </div>
            </div>
            <div className="hidden md:block w-48">
              <p className="text-cream/40 text-xs font-inter mb-2">
                {tier.next ? `${tier.pointsNeeded - user.loyaltyPoints} pts to ${tier.next}` : "Max tier reached!"}
              </p>
              <div className="h-2 rounded-full bg-charcoal/50 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  className="h-full rounded-full bg-gradient-gold"
                />
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-[240px_1fr] gap-6">
          {/* Sidebar Tabs */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass rounded-2xl p-3 h-fit"
          >
            <div className="space-y-1">
              {tabConfig.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl text-sm font-inter transition-all ${
                    activeTab === tab.key
                      ? "bg-gradient-gold text-charcoal-dark font-semibold"
                      : "text-cream/60 hover:text-gold hover:bg-gold/5"
                  }`}
                >
                  <tab.icon size={18} />
                  {tab.label}
                </button>
              ))}
              <div className="section-divider my-2" />
              <button
                onClick={logout}
                className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-sm font-inter text-red-400/60 hover:text-red-400 hover:bg-red-500/5 transition-all"
              >
                <LogOut size={18} />
                Sign Out
              </button>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="min-h-[500px]"
          >
            <AnimatePresence mode="wait">
              {/* Profile Tab */}
              {activeTab === "profile" && (
                <motion.div key="profile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="glass rounded-2xl p-6 md:p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="font-playfair text-xl font-bold text-cream">Personal Information</h2>
                    <button onClick={() => setEditing(!editing)} className="flex items-center gap-2 text-gold text-sm font-inter hover:text-gold-light transition-colors">
                      {editing ? <Save size={16} /> : <Edit3 size={16} />}
                      {editing ? "Cancel" : "Edit"}
                    </button>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-cream/50 text-xs font-inter mb-1.5 tracking-wider uppercase">Full Name</label>
                      {editing ? (
                        <input value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-4 py-3 text-cream font-inter focus:outline-none focus:border-gold/60 transition-colors" />
                      ) : (
                        <p className="text-cream font-inter flex items-center gap-2"><User size={16} className="text-gold/50" />{user.name}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-cream/50 text-xs font-inter mb-1.5 tracking-wider uppercase">Email</label>
                      <p className="text-cream font-inter flex items-center gap-2"><Mail size={16} className="text-gold/50" />{user.email}</p>
                    </div>
                    <div>
                      <label className="block text-cream/50 text-xs font-inter mb-1.5 tracking-wider uppercase">Phone</label>
                      {editing ? (
                        <input value={formPhone} onChange={(e) => setFormPhone(e.target.value)} placeholder="(555) 123-4567" className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-4 py-3 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors" />
                      ) : (
                        <p className="text-cream font-inter flex items-center gap-2"><Phone size={16} className="text-gold/50" />{user.phone || "Not set"}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-cream/50 text-xs font-inter mb-1.5 tracking-wider uppercase">Address</label>
                      {editing ? (
                        <input value={formAddress} onChange={(e) => setFormAddress(e.target.value)} placeholder="123 Main St, NYC" className="w-full bg-charcoal/50 border border-gold/20 rounded-xl px-4 py-3 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors" />
                      ) : (
                        <p className="text-cream font-inter flex items-center gap-2"><MapPin size={16} className="text-gold/50" />{user.address || "Not set"}</p>
                      )}
                    </div>
                  </div>

                  {editing && (
                    <div className="mt-6">
                      <button onClick={handleSaveProfile} disabled={saving} className="btn-premium bg-gradient-gold text-charcoal-dark px-8 py-3 rounded-full font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all disabled:opacity-50">
                        {saving ? "Saving..." : "Save Changes"}
                      </button>
                    </div>
                  )}

                  <div className="section-divider mt-8 mb-6" />

                  {/* Loyalty Card */}
                  <div className={`bg-gradient-to-br ${tier.color} rounded-2xl p-6 text-charcoal-dark relative overflow-hidden`}>
                    <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
                    <div className="relative">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <Crown size={20} />
                          <span className="font-playfair font-bold uppercase tracking-wider">{user.memberTier} Member</span>
                        </div>
                        <span className="font-playfair text-sm font-bold opacity-60">AUREUM</span>
                      </div>
                      <p className="font-playfair text-3xl font-bold mb-1">{user.loyaltyPoints} <span className="text-lg">pts</span></p>
                      <p className="text-sm opacity-70 font-inter">{user.name}</p>
                      {tier.next && (
                        <div className="mt-4">
                          <div className="flex justify-between text-xs opacity-70 font-inter mb-1">
                            <span>Progress to {tier.next}</span>
                            <span>{Math.round(progress)}%</span>
                          </div>
                          <div className="h-1.5 rounded-full bg-black/20 overflow-hidden">
                            <div className="h-full rounded-full bg-white/80" style={{ width: `${progress}%` }} />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Orders Tab */}
              {activeTab === "orders" && (
                <motion.div key="orders" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
                  <div className="glass rounded-2xl p-6">
                    <h2 className="font-playfair text-xl font-bold text-cream mb-2">Order History</h2>
                    <p className="text-cream/40 text-sm font-inter">Track all your past and current orders</p>
                  </div>

                  {orders.length === 0 ? (
                    <div className="glass rounded-2xl p-12 text-center">
                      <ShoppingBag className="mx-auto text-gold/30 mb-4" size={48} />
                      <h3 className="font-playfair text-lg text-cream mb-2">No Orders Yet</h3>
                      <p className="text-cream/40 text-sm font-inter mb-6">Start your culinary journey with your first order!</p>
                      <Link href="/menu" className="btn-premium bg-gradient-gold text-charcoal-dark px-6 py-2.5 rounded-full text-sm font-semibold tracking-wider uppercase">
                        Browse Menu
                      </Link>
                    </div>
                  ) : (
                    orders.map((order) => (
                      <div key={order.id} className="glass rounded-2xl p-5">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <p className="text-cream font-playfair font-semibold">Order #{order.id}</p>
                            <p className="text-cream/40 text-xs font-inter">{order.createdAt ? new Date(order.createdAt).toLocaleDateString() : "N/A"} • {order.orderType}</p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold capitalize ${statusColor(order.status)}`}>
                            {order.status}
                          </span>
                        </div>
                        <div className="space-y-1 mb-3">
                          {(Array.isArray(order.items) ? order.items : []).map((item: { name: string; quantity: number; price: number }, i: number) => (
                            <p key={i} className="text-cream/60 text-sm font-inter">{item.quantity}x {item.name} — ${(item.price * item.quantity).toFixed(2)}</p>
                          ))}
                        </div>
                        <div className="flex items-center justify-between pt-3 border-t border-gold/10">
                          <span className="text-gold font-semibold font-playfair">${order.total.toFixed(2)}</span>
                          <Link href="/menu" className="text-gold/60 text-xs font-inter hover:text-gold transition-colors flex items-center gap-1">
                            Reorder <ChevronRight size={12} />
                          </Link>
                        </div>
                      </div>
                    ))
                  )}
                </motion.div>
              )}

              {/* Favorites Tab */}
              {activeTab === "favorites" && (
                <motion.div key="favorites" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                  <div className="glass rounded-2xl p-6 mb-4">
                    <h2 className="font-playfair text-xl font-bold text-cream mb-2">My Favorites</h2>
                    <p className="text-cream/40 text-sm font-inter">Your saved dishes for quick reordering</p>
                  </div>

                  {(!user.favorites || user.favorites.length === 0) ? (
                    <div className="glass rounded-2xl p-12 text-center">
                      <Heart className="mx-auto text-gold/30 mb-4" size={48} />
                      <h3 className="font-playfair text-lg text-cream mb-2">No Favorites Yet</h3>
                      <p className="text-cream/40 text-sm font-inter mb-6">Browse our menu and heart the dishes you love!</p>
                      <Link href="/menu" className="btn-premium bg-gradient-gold text-charcoal-dark px-6 py-2.5 rounded-full text-sm font-semibold tracking-wider uppercase">
                        Explore Menu
                      </Link>
                    </div>
                  ) : (
                    <div className="glass rounded-2xl p-6 text-center">
                      <Gift className="mx-auto text-gold/50 mb-3" size={32} />
                      <p className="text-cream/60 text-sm font-inter">You have {user.favorites.length} saved favorite(s). Visit the menu to see them!</p>
                      <Link href="/menu" className="inline-flex mt-4 btn-premium bg-gradient-gold text-charcoal-dark px-6 py-2.5 rounded-full text-sm font-semibold tracking-wider uppercase">
                        View Menu
                      </Link>
                    </div>
                  )}
                </motion.div>
              )}

              {/* Reservations Tab */}
              {activeTab === "reservations" && (
                <motion.div key="reservations" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
                  <div className="glass rounded-2xl p-6">
                    <h2 className="font-playfair text-xl font-bold text-cream mb-2">My Reservations</h2>
                    <p className="text-cream/40 text-sm font-inter">View and manage your table bookings</p>
                  </div>

                  {reservations.length === 0 ? (
                    <div className="glass rounded-2xl p-12 text-center">
                      <CalendarDays className="mx-auto text-gold/30 mb-4" size={48} />
                      <h3 className="font-playfair text-lg text-cream mb-2">No Reservations</h3>
                      <p className="text-cream/40 text-sm font-inter mb-6">Book a table for your next dining experience!</p>
                      <Link href="/#reservations" className="btn-premium bg-gradient-gold text-charcoal-dark px-6 py-2.5 rounded-full text-sm font-semibold tracking-wider uppercase">
                        Reserve Now
                      </Link>
                    </div>
                  ) : (
                    reservations.map((res) => (
                      <div key={res.id} className="glass rounded-2xl p-5">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="text-cream font-playfair font-semibold">{res.date} at {res.time}</p>
                            <p className="text-cream/50 text-sm font-inter">{res.guests} guests {res.occasion ? `• ${res.occasion}` : ""}</p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold capitalize ${statusColor(res.status)}`}>
                            {res.status}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </motion.div>
              )}

              {/* Settings Tab */}
              {activeTab === "settings" && (
                <motion.div key="settings" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="glass rounded-2xl p-6 md:p-8">
                  <h2 className="font-playfair text-xl font-bold text-cream mb-6">Account Settings</h2>
                  
                  <div className="space-y-6">
                    <div className="flex items-center justify-between p-4 rounded-xl hover:bg-gold/5 transition-all">
                      <div>
                        <p className="text-cream font-inter font-medium text-sm">Email Notifications</p>
                        <p className="text-cream/40 text-xs font-inter">Receive order updates & promotions</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" defaultChecked className="sr-only peer" />
                        <div className="w-11 h-6 bg-charcoal rounded-full peer peer-checked:bg-gold/60 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all" />
                      </label>
                    </div>

                    <div className="flex items-center justify-between p-4 rounded-xl hover:bg-gold/5 transition-all">
                      <div>
                        <p className="text-cream font-inter font-medium text-sm">SMS Alerts</p>
                        <p className="text-cream/40 text-xs font-inter">Reservation & delivery reminders</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" defaultChecked className="sr-only peer" />
                        <div className="w-11 h-6 bg-charcoal rounded-full peer peer-checked:bg-gold/60 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all" />
                      </label>
                    </div>

                    <div className="flex items-center justify-between p-4 rounded-xl hover:bg-gold/5 transition-all">
                      <div>
                        <p className="text-cream font-inter font-medium text-sm">Promotional Offers</p>
                        <p className="text-cream/40 text-xs font-inter">Special deals & seasonal offers</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" />
                        <div className="w-11 h-6 bg-charcoal rounded-full peer peer-checked:bg-gold/60 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all" />
                      </label>
                    </div>

                    <div className="section-divider" />

                    <div className="p-4 rounded-xl border border-red-500/20 bg-red-500/5">
                      <p className="text-red-400 font-inter font-medium text-sm mb-1">Danger Zone</p>
                      <p className="text-red-400/50 text-xs font-inter mb-4">Once you delete your account, there&apos;s no going back.</p>
                      <button className="text-red-400 text-xs font-semibold px-4 py-2 rounded-lg border border-red-500/30 hover:bg-red-500/10 transition-all">
                        Delete Account
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
