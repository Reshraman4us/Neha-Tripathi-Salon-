"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import { Mail, Lock, User, Eye, EyeOff, ArrowRight, CheckCircle2, Sparkles, Award, Heart, Clock } from "lucide-react";
import { useAuth } from "@/lib/auth-context";

export default function AuthPageClient() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const router = useRouter();
  const { user, login, register } = useAuth();

  useEffect(() => {
    if (user) router.push("/profile");
  }, [user, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    if (mode === "register" && password !== confirmPassword) {
      setError("Passwords don't match");
      setSubmitting(false);
      return;
    }

    const result = mode === "login"
      ? await login(email, password)
      : await register(name, email, password);

    if (result.success) {
      router.push("/profile");
    } else {
      setError(result.error || "Something went wrong");
    }
    setSubmitting(false);
  };

  const perks = [
    { icon: Award, title: "Loyalty Rewards", desc: "Earn points on every order" },
    { icon: Heart, title: "Save Favorites", desc: "Quick reorder your loved dishes" },
    { icon: Clock, title: "Order History", desc: "Track all orders & reservations" },
    { icon: Sparkles, title: "Member Exclusive", desc: "Birthday rewards & VIP perks" },
  ];

  if (user) return null;

  return (
    <div className="pt-24 pb-16 min-h-screen flex items-center">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left — Perks / Branding */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="hidden lg:block"
          >
            <span className="text-gold text-sm font-inter tracking-[0.2em] uppercase mb-4 block">
              Welcome to AUREUM
            </span>
            <h1 className="font-playfair text-5xl font-bold mb-6 leading-tight">
              <span className="text-cream">Your Premium</span>
              <br />
              <span className="text-gradient">Dining Experience</span>
              <br />
              <span className="text-cream italic">Awaits</span>
            </h1>
            <p className="text-cream/50 font-inter leading-relaxed mb-10 max-w-md">
              Join AUREUM to unlock exclusive member benefits, earn loyalty points, 
              save your favorite dishes, and manage your reservations — all in one place.
            </p>

            <div className="grid grid-cols-2 gap-4">
              {perks.map((perk) => (
                <div key={perk.title} className="glass-light rounded-xl p-4 hover:bg-gold/10 transition-all">
                  <perk.icon className="text-gold mb-2" size={22} />
                  <p className="text-cream font-playfair font-semibold text-sm">{perk.title}</p>
                  <p className="text-cream/40 text-xs font-inter mt-0.5">{perk.desc}</p>
                </div>
              ))}
            </div>

            {/* Decorative */}
            <div className="mt-10 flex items-center gap-4">
              <div className="flex -space-x-3">
                {["https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=80", "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80"].map((src, i) => (
                  <img key={i} src={src} alt="" className="w-10 h-10 rounded-full border-2 border-charcoal-dark object-cover" />
                ))}
              </div>
              <div>
                <p className="text-cream/70 text-sm font-inter font-medium">Join 50K+ Members</p>
                <p className="text-cream/40 text-xs font-inter">who love dining with us</p>
              </div>
            </div>
          </motion.div>

          {/* Right — Auth Form */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="glass rounded-3xl p-8 md:p-10 max-w-md mx-auto">
              {/* Tabs */}
              <div className="flex gap-1 mb-8 p-1 rounded-xl bg-charcoal/30">
                <button
                  onClick={() => { setMode("login"); setError(""); }}
                  className={`flex-1 py-3 rounded-lg text-sm font-semibold tracking-wider uppercase transition-all font-inter ${
                    mode === "login" ? "bg-gradient-gold text-charcoal-dark" : "text-cream/50 hover:text-gold"
                  }`}
                >
                  Sign In
                </button>
                <button
                  onClick={() => { setMode("register"); setError(""); }}
                  className={`flex-1 py-3 rounded-lg text-sm font-semibold tracking-wider uppercase transition-all font-inter ${
                    mode === "register" ? "bg-gradient-gold text-charcoal-dark" : "text-cream/50 hover:text-gold"
                  }`}
                >
                  Register
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <AnimatePresence mode="wait">
                  {mode === "register" && (
                    <motion.div
                      key="name"
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <label className="block text-cream/70 text-xs font-inter mb-1.5 tracking-wider uppercase">Full Name</label>
                      <div className="relative">
                        <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-cream/30" />
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="w-full bg-charcoal/50 border border-gold/20 rounded-xl pl-12 pr-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                          placeholder="John Smith"
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div>
                  <label className="block text-cream/70 text-xs font-inter mb-1.5 tracking-wider uppercase">Email Address</label>
                  <div className="relative">
                    <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-cream/30" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-charcoal/50 border border-gold/20 rounded-xl pl-12 pr-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                      placeholder="you@example.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-cream/70 text-xs font-inter mb-1.5 tracking-wider uppercase">Password</label>
                  <div className="relative">
                    <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-cream/30" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-charcoal/50 border border-gold/20 rounded-xl pl-12 pr-12 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                      placeholder="Min 6 characters"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-cream/30 hover:text-gold transition-colors"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>

                <AnimatePresence mode="wait">
                  {mode === "register" && (
                    <motion.div
                      key="confirm"
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <label className="block text-cream/70 text-xs font-inter mb-1.5 tracking-wider uppercase">Confirm Password</label>
                      <div className="relative">
                        <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-cream/30" />
                        <input
                          type={showPassword ? "text" : "password"}
                          required
                          minLength={6}
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          className="w-full bg-charcoal/50 border border-gold/20 rounded-xl pl-12 pr-5 py-3.5 text-cream font-inter placeholder-cream/30 focus:outline-none focus:border-gold/60 transition-colors"
                          placeholder="Repeat password"
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {error && (
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-red-400 text-sm font-inter bg-red-500/10 rounded-lg p-3 border border-red-500/20"
                  >
                    {error}
                  </motion.p>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full btn-premium bg-gradient-gold text-charcoal-dark py-4 rounded-full font-semibold tracking-wider uppercase hover:shadow-xl hover:shadow-gold/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2 text-sm"
                >
                  {submitting ? (
                    "Processing..."
                  ) : mode === "login" ? (
                    <>Sign In <ArrowRight size={16} /></>
                  ) : (
                    <>Create Account <CheckCircle2 size={16} /></>
                  )}
                </button>
              </form>

              <p className="text-center text-cream/30 text-xs font-inter mt-6">
                {mode === "login"
                  ? "Don't have an account? "
                  : "Already have an account? "}
                <button
                  onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}
                  className="text-gold hover:text-gold-light transition-colors font-medium"
                >
                  {mode === "login" ? "Register now" : "Sign in"}
                </button>
              </p>

              <div className="section-divider mt-6 mb-4" />
              <p className="text-center text-cream/20 text-[10px] font-inter">
                🔒 Your information is secure and encrypted
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
