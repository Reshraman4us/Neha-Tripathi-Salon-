import { db } from "@/db";
import { menuCategories, menuItems, testimonials } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function seedDatabase() {
  const existing = await db.select().from(menuCategories).limit(1);
  if (existing.length > 0) return;

  const cats = await db.insert(menuCategories).values([
    { name: "Starters", slug: "starters", description: "Begin your culinary journey", image: "https://images.unsplash.com/photo-1541014741259-de529411b96a?w=600", sortOrder: 1 },
    { name: "Main Course", slug: "main-course", description: "Signature dishes crafted to perfection", image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=600", sortOrder: 2 },
    { name: "Seafood", slug: "seafood", description: "Fresh from the ocean", image: "https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?w=600", sortOrder: 3 },
    { name: "Steaks", slug: "steaks", description: "Premium cuts, perfectly aged", image: "https://images.unsplash.com/photo-1600891964092-4316c288032e?w=600", sortOrder: 4 },
    { name: "Pizza & Pasta", slug: "pizza-pasta", description: "Italian classics reimagined", image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600", sortOrder: 5 },
    { name: "Burgers", slug: "burgers", description: "Gourmet burgers with premium ingredients", image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600", sortOrder: 6 },
    { name: "Desserts", slug: "desserts", description: "Sweet finales to remember", image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=600", sortOrder: 7 },
    { name: "Drinks", slug: "drinks", description: "Handcrafted cocktails & fine wines", image: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=600", sortOrder: 8 },
  ]).returning();

  const catMap: Record<string, number> = {};
  cats.forEach(c => { catMap[c.slug] = c.id; });

  await db.insert(menuItems).values([
    // Starters
    { categoryId: catMap["starters"], name: "Truffle Burrata", slug: "truffle-burrata", description: "Creamy burrata with black truffle, heirloom tomatoes & aged balsamic", price: 24, image: "https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=500", calories: 320, ingredients: "Burrata, Black Truffle, Heirloom Tomatoes, Balsamic, Basil", isPopular: true, rating: 4.9, reviewCount: 128 },
    { categoryId: catMap["starters"], name: "Wagyu Carpaccio", slug: "wagyu-carpaccio", description: "Thinly sliced A5 Wagyu with arugula, capers & truffle oil", price: 32, image: "https://images.unsplash.com/photo-1608039829572-26e7b15e0f00?w=500", calories: 280, ingredients: "A5 Wagyu, Arugula, Capers, Truffle Oil, Parmesan", isNew: true, rating: 4.8, reviewCount: 64 },
    { categoryId: catMap["starters"], name: "Lobster Bisque", slug: "lobster-bisque", description: "Rich & velvety lobster soup with cognac cream and chive oil", price: 22, image: "https://images.unsplash.com/photo-1547592166-23ac45744aec?w=500", calories: 380, ingredients: "Maine Lobster, Cream, Cognac, Chives, Butter", rating: 4.7, reviewCount: 95 },
    { categoryId: catMap["starters"], name: "Tuna Tartare", slug: "tuna-tartare", description: "Yellowfin tuna with avocado, sesame, ginger & crispy wonton", price: 26, image: "https://images.unsplash.com/photo-1579631542720-3a87824fff86?w=500", calories: 240, ingredients: "Yellowfin Tuna, Avocado, Sesame, Ginger, Soy", isPopular: true, rating: 4.8, reviewCount: 112 },

    // Main Course
    { categoryId: catMap["main-course"], name: "Herb-Crusted Rack of Lamb", slug: "rack-of-lamb", description: "New Zealand lamb rack with rosemary jus, truffle mash & seasonal vegetables", price: 58, image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=500", calories: 680, ingredients: "NZ Lamb, Rosemary, Truffle, Potato, Seasonal Vegetables", isPopular: true, rating: 4.9, reviewCount: 203 },
    { categoryId: catMap["main-course"], name: "Duck Confit", slug: "duck-confit", description: "Slow-cooked duck leg with cherry gastrique, parsnip purée & crispy kale", price: 46, image: "https://images.unsplash.com/photo-1432139509613-5c4255a1d197?w=500", calories: 720, ingredients: "Duck Leg, Cherry, Parsnip, Kale, Thyme", rating: 4.7, reviewCount: 87 },
    { categoryId: catMap["main-course"], name: "Pan-Seared Chicken Supreme", slug: "chicken-supreme", description: "Free-range chicken with morel mushroom sauce & gratin dauphinois", price: 38, image: "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=500", calories: 560, ingredients: "Free-Range Chicken, Morel Mushrooms, Cream, Gruyère, Potato", rating: 4.6, reviewCount: 156 },

    // Seafood
    { categoryId: catMap["seafood"], name: "Grilled Mediterranean Branzino", slug: "grilled-branzino", description: "Whole branzino with lemon herb butter, roasted fennel & citrus salad", price: 52, image: "https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?w=500", calories: 420, ingredients: "Branzino, Lemon, Herbs, Fennel, Citrus", isPopular: true, rating: 4.8, reviewCount: 134 },
    { categoryId: catMap["seafood"], name: "Butter-Poached Lobster Tail", slug: "lobster-tail", description: "Maine lobster tail with drawn butter, asparagus & saffron risotto", price: 72, image: "https://images.unsplash.com/photo-1559737558-2f5a35f4523b?w=500", calories: 580, ingredients: "Maine Lobster, Butter, Asparagus, Saffron, Arborio Rice", isNew: true, rating: 4.9, reviewCount: 78 },
    { categoryId: catMap["seafood"], name: "Seared Scallops", slug: "seared-scallops", description: "Day-boat scallops with cauliflower purée, pancetta & brown butter", price: 48, image: "https://images.unsplash.com/photo-1599084993091-1cb5c0721cc6?w=500", calories: 340, ingredients: "Day-Boat Scallops, Cauliflower, Pancetta, Brown Butter, Capers", rating: 4.8, reviewCount: 189 },

    // Steaks
    { categoryId: catMap["steaks"], name: "Prime Ribeye 16oz", slug: "prime-ribeye", description: "USDA Prime bone-in ribeye with peppercorn sauce & loaded baked potato", price: 78, image: "https://images.unsplash.com/photo-1600891964092-4316c288032e?w=500", calories: 920, ingredients: "USDA Prime Beef, Peppercorn, Butter, Potato, Sour Cream", isPopular: true, rating: 4.9, reviewCount: 312 },
    { categoryId: catMap["steaks"], name: "A5 Japanese Wagyu", slug: "a5-wagyu", description: "A5 Miyazaki Wagyu strip with wasabi, pickled ginger & ponzu", price: 165, image: "https://images.unsplash.com/photo-1558030006-450675393462?w=500", calories: 650, ingredients: "A5 Miyazaki Wagyu, Wasabi, Ginger, Ponzu, Sea Salt", isNew: true, isPopular: true, rating: 5.0, reviewCount: 56 },
    { categoryId: catMap["steaks"], name: "Filet Mignon 8oz", slug: "filet-mignon", description: "Center-cut filet with béarnaise sauce, roasted mushrooms & truffle fries", price: 68, image: "https://images.unsplash.com/photo-1588168333986-5078d3ae3976?w=500", calories: 580, ingredients: "Prime Beef Tenderloin, Béarnaise, Mushrooms, Truffle, Fries", rating: 4.8, reviewCount: 245 },

    // Pizza & Pasta
    { categoryId: catMap["pizza-pasta"], name: "Truffle & Burrata Pizza", slug: "truffle-burrata-pizza", description: "Wood-fired pizza with black truffle, fresh burrata & wild mushrooms", price: 28, image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=500", calories: 720, ingredients: "San Marzano Tomatoes, Burrata, Black Truffle, Wild Mushrooms, Basil", isPopular: true, rating: 4.7, reviewCount: 167 },
    { categoryId: catMap["pizza-pasta"], name: "Lobster Linguine", slug: "lobster-linguine", description: "Fresh linguine with butter-poached lobster, cherry tomatoes & basil", price: 42, image: "https://images.unsplash.com/photo-1563379926898-05f4575a45d8?w=500", calories: 680, ingredients: "Fresh Linguine, Maine Lobster, Cherry Tomatoes, Basil, White Wine", rating: 4.8, reviewCount: 98 },
    { categoryId: catMap["pizza-pasta"], name: "Black Truffle Risotto", slug: "truffle-risotto", description: "Carnaroli rice with black truffle, parmigiano & brown butter", price: 36, image: "https://images.unsplash.com/photo-1476124369491-e7addf5db371?w=500", calories: 520, ingredients: "Carnaroli Rice, Black Truffle, Parmigiano Reggiano, Brown Butter", isVegan: false, rating: 4.7, reviewCount: 143 },

    // Burgers
    { categoryId: catMap["burgers"], name: "The Aureum Burger", slug: "aureum-burger", description: "Double wagyu patty with aged cheddar, truffle aioli, caramelized onions & brioche bun", price: 34, image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500", calories: 980, ingredients: "Wagyu Beef, Aged Cheddar, Truffle Aioli, Caramelized Onions, Brioche", isPopular: true, isSpicy: false, rating: 4.9, reviewCount: 278 },
    { categoryId: catMap["burgers"], name: "Spicy Nashville Chicken", slug: "nashville-chicken", description: "Crispy Nashville-style chicken with coleslaw, pickles & honey butter", price: 26, image: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=500", calories: 850, ingredients: "Chicken Breast, Nashville Spice, Coleslaw, Pickles, Honey Butter", isSpicy: true, rating: 4.6, reviewCount: 195 },

    // Desserts
    { categoryId: catMap["desserts"], name: "Dark Chocolate Fondant", slug: "chocolate-fondant", description: "Valrhona dark chocolate fondant with vanilla bean ice cream & gold leaf", price: 18, image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=500", calories: 460, ingredients: "Valrhona Chocolate, Butter, Eggs, Vanilla Bean Ice Cream, Gold Leaf", isPopular: true, rating: 4.9, reviewCount: 234 },
    { categoryId: catMap["desserts"], name: "Crème Brûlée", slug: "creme-brulee", description: "Classic Madagascar vanilla crème brûlée with caramelized sugar crust", price: 16, image: "https://images.unsplash.com/photo-1470124182917-cc6e71b22ecc?w=500", calories: 380, ingredients: "Cream, Eggs, Madagascar Vanilla, Sugar", rating: 4.8, reviewCount: 189 },
    { categoryId: catMap["desserts"], name: "Tiramisu", slug: "tiramisu", description: "Traditional Italian tiramisu with espresso, mascarpone & cocoa", price: 17, image: "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=500", calories: 420, ingredients: "Mascarpone, Espresso, Ladyfingers, Cocoa, Amaretto", rating: 4.7, reviewCount: 156 },

    // Drinks
    { categoryId: catMap["drinks"], name: "The Golden Hour", slug: "golden-hour", description: "Bourbon, honey syrup, fresh lemon, gold flakes & aromatic bitters", price: 22, image: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=500", calories: 180, ingredients: "Bourbon, Honey, Lemon, Gold Flakes, Bitters", isPopular: true, rating: 4.8, reviewCount: 167 },
    { categoryId: catMap["drinks"], name: "Truffle Martini", slug: "truffle-martini", description: "Vodka, truffle-infused vermouth, olive brine & truffle oil garnish", price: 24, image: "https://images.unsplash.com/photo-1575023782549-62ca0d244b39?w=500", calories: 160, ingredients: "Premium Vodka, Truffle Vermouth, Olive Brine, Truffle Oil", isNew: true, rating: 4.7, reviewCount: 89 },
    { categoryId: catMap["drinks"], name: "Sommelier's Wine Selection", slug: "wine-selection", description: "Curated glass of our sommelier's daily pick from our exclusive cellar", price: 28, image: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=500", calories: 125, ingredients: "Varies Daily", rating: 4.9, reviewCount: 203 },
  ]).returning();

  await db.insert(testimonials).values([
    { name: "James Anderson", role: "Food Critic, NY Times", content: "AUREUM delivers an extraordinary dining experience. Every dish is a masterpiece, and the ambiance is simply unmatched. This is fine dining at its absolute peak.", rating: 5, image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200", featured: true },
    { name: "Sarah Mitchell", role: "Michelin Guide Reviewer", content: "The attention to detail at AUREUM is remarkable. From the truffle-infused appetizers to the perfectly aged steaks, every bite tells a story of culinary excellence.", rating: 5, image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200", featured: true },
    { name: "Robert Chen", role: "Celebrity Chef", content: "As a chef myself, I rarely find restaurants that truly impress me. AUREUM is that rare gem. Their A5 Wagyu alone is worth the visit. Absolutely phenomenal.", rating: 5, image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200", featured: true },
    { name: "Emily Rodriguez", role: "Regular Guest", content: "We celebrated our 10th anniversary at AUREUM and it was magical. The staff made us feel like royalty. The chocolate fondant is to die for!", rating: 5, image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200", featured: true },
    { name: "Michael Thompson", role: "Wine Enthusiast", content: "AUREUM's wine cellar is extraordinary. Their sommelier paired each course perfectly. The Golden Hour cocktail is now my absolute favorite.", rating: 5, image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200", featured: false },
    { name: "Lisa Park", role: "Food Blogger", content: "If you're looking for the ultimate fine dining experience in the city, look no further. AUREUM sets the gold standard. Every visit feels like a special occasion.", rating: 5, image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200", featured: true },
  ]);
}
