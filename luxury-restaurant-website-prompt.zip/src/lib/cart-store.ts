// Simple client-side cart state management
export interface CartItem {
  id: number;
  name: string;
  price: number;
  image: string;
  quantity: number;
}

const CART_KEY = "aureum_cart";

export function getCart(): CartItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(CART_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveCart(items: CartItem[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem(CART_KEY, JSON.stringify(items));
  window.dispatchEvent(new Event("cart-updated"));
}

export function addToCart(item: Omit<CartItem, "quantity">) {
  const cart = getCart();
  const existing = cart.find((c) => c.id === item.id);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ ...item, quantity: 1 });
  }
  saveCart(cart);
}

export function removeFromCart(id: number) {
  const cart = getCart().filter((c) => c.id !== id);
  saveCart(cart);
}

export function updateQuantity(id: number, quantity: number) {
  const cart = getCart();
  const item = cart.find((c) => c.id === id);
  if (item) {
    item.quantity = Math.max(0, quantity);
    if (item.quantity === 0) {
      saveCart(cart.filter((c) => c.id !== id));
    } else {
      saveCart(cart);
    }
  }
}

export function clearCart() {
  saveCart([]);
}

export function getCartTotal(items: CartItem[]) {
  return items.reduce((sum, i) => sum + i.price * i.quantity, 0);
}

export function getCartCount(items: CartItem[]) {
  return items.reduce((sum, i) => sum + i.quantity, 0);
}
